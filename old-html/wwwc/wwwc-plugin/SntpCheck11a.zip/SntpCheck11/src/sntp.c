/*
 *  SntpCheck (WWWC�̃v���O�C��)
 *
 *  sntp.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <time.h>
#include "wwwcdll.h"
#include "dns.h"
#include "misc.h"
#include "sntp.h"

extern HINSTANCE g_hInst;
int SendPacket(HWND hWnd,struct TPITEM *tpItemInfo,unsigned long address,short nPort);
int SelectRecv(HWND hWnd,struct TPITEM *tpItemInfo);
void CloseSocket(HWND hWnd,struct TPITEM *tpItemInfo);

__declspec(dllexport) int CALLBACK SNTP_Property(HWND hWnd,struct TPITEM *tpItemInfo);

/*
 * WWWC�̃X�e�[�^�X�o�[�Ƀe�L�X�g��\������֐�
 */
int SetStatusBar(HWND hWnd,char *format,...)
{
    va_list va_arg;
    int n = 0;
    char *buf = NULL;

    buf = Malloc(8 * 1024);
    if(buf){
        va_start(va_arg,format);
        n = vsprintf(buf,format,va_arg);
        va_end(va_arg);
        SendMessage(GetDlgItem(hWnd, WWWC_SB),SB_SETTEXT,(WPARAM)0,(LPARAM)buf);
        Free(buf);
    }
    return n;
}

/*
 *  �A�C�R��������������Ƃ��ɌĂ΂��
 */
__declspec(dllexport) int CALLBACK SNTP_InitItem(HWND hWnd,struct TPITEM *tpItemInfo)
{
    if(tpItemInfo->ErrStatus != NULL){
        GlobalFree(tpItemInfo->ErrStatus);
        tpItemInfo->ErrStatus = NULL;
    }
    if((tpItemInfo->Status & ST_UP) == 0){
        /* �X�V�}�[�N(*)���������� */
        if(tpItemInfo->Size != NULL && *tpItemInfo->Size != '\0' &&
            *(tpItemInfo->Size + lstrlen(tpItemInfo->Size) - 1) == '*'){
            *(tpItemInfo->Size + lstrlen(tpItemInfo->Size) - 1) = '\0';
        }
        if(tpItemInfo->Date != NULL && *tpItemInfo->Date != '\0' &&
            *(tpItemInfo->Date + lstrlen(tpItemInfo->Date) - 1) == '*'){
            *(tpItemInfo->Date + lstrlen(tpItemInfo->Date) - 1) = '\0';
        }
    }
    return 0;
}

/*
 *  �`�F�b�N�J�n�̂Ƃ��ɃA�C�e�������������邽�߂ɌĂ΂��֐��B
 */
__declspec(dllexport) int CALLBACK SNTP_Initialize(HWND hWnd,struct TPITEM *tpItemInfo)
{
    if(tpItemInfo->ErrStatus){
        GlobalFree(tpItemInfo->ErrStatus);
        tpItemInfo->ErrStatus = NULL;
    }
    tpItemInfo->user1 = 0;
    tpItemInfo->user2 = 0;
    return 0;
}

/*
 *  �`�F�b�N�𒆎~����֐�
 */
__declspec(dllexport) int CALLBACK SNTP_Cancel(HWND hWnd,struct TPITEM *tpItemInfo)
{
    CloseSocket(hWnd,tpItemInfo);
    return 0;
}

/*
 *  1�b���ƂɌĂ΂��֐��B�A�C�e���`�F�b�N�̃^�C���A�E�g����������B
 */
__declspec(dllexport) int CALLBACK SNTP_Timer(HWND hWnd,struct TPITEM *tpItemInfo)
{
    if(tpItemInfo->user1 == -1){
        return CHECK_SUCCEED;
    }
    tpItemInfo->user1++;

    if(tpItemInfo->user1 >= TIMEOUT){
        tpItemInfo->user1 = -1;
        SetErrorMessage(tpItemInfo,WSAETIMEDOUT);
        SendMessage(hWnd,WM_CHECKEND,ST_TIMEOUT,(LPARAM)tpItemInfo);
        return CHECK_END;
    }
    return CHECK_SUCCEED;
}

/*
 *  �A�C�e���̃`�F�b�N���J�n����֐�
 */
__declspec(dllexport) int CALLBACK SNTP_Start(HWND hWnd,struct TPITEM *tpItemInfo)
{
    struct TPSNTP *tpSNTP = NULL;
    unsigned long addr;

    if(tpItemInfo->Param1 == 0){
        tpSNTP = Malloc(sizeof(struct TPSNTP));
        if(tpSNTP == NULL){
            return CHECK_ERROR;
        }
        tpItemInfo->user1 = 0;
        tpItemInfo->Param1 = (long)tpSNTP;
        ParseParameter(tpItemInfo,tpSNTP);
    }

    tpItemInfo->Soc1 = socket(AF_INET,SOCK_DGRAM,0);
    if(tpItemInfo->Soc1 == INVALID_SOCKET){
        SetErrorMessage(tpItemInfo,WSAGetLastError());
        return CHECK_ERROR;
    }

    addr = inet_addr(tpSNTP->szServer);
    if(addr == -1){
        addr = GetDNSCache(tpSNTP->szServer);
    }
    if(addr == -1){
        SetStatusBar(hWnd,"IP�A�h���X���擾��...");

        memset(tpSNTP->HostEnt,0,MAXGETHOSTSTRUCT);
        tpItemInfo->hGetHost1 = WSAAsyncGetHostByName(hWnd,
                                                      WM_WSOCK_GETHOST,
                                                      tpSNTP->szServer,
                                                      tpSNTP->HostEnt,
                                                      MAXGETHOSTSTRUCT);
        if(tpItemInfo->hGetHost1 == NULL){
            tpItemInfo->user1 = -1;
            SetErrorMessage(tpItemInfo,WSAGetLastError());
            SendMessage(hWnd,WM_CHECKEND,ST_ERROR,(LPARAM)tpItemInfo);
            return CHECK_ERROR;
        }
        return CHECK_SUCCEED;
    }
    if(WSAAsyncSelect(tpItemInfo->Soc1,hWnd,WM_WSOCK_SELECT,FD_READ) == SOCKET_ERROR){
        SetErrorMessage(tpItemInfo,WSAGetLastError());
        return CHECK_ERROR;
    }

    SetStatusBar(hWnd,"���N�G�X�g�𑗐M��...");
    if(SendPacket(hWnd,tpItemInfo,addr,tpSNTP->nPort)){
        GetSystemTimeAsFileTime(&tpSNTP->ftSend);
        return CHECK_SUCCEED;
    }
    return CHECK_ERROR;
}

/*
 *  Select�C�x���g�n���h��
 */
__declspec(dllexport) int CALLBACK SNTP_Select(HWND hWnd,WPARAM wParam,LPARAM lParam,struct TPITEM *tpItemInfo)
{
    struct TPSNTP *tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;
    if(tpSNTP == NULL){
        SendMessage(hWnd,WM_CHECKEND,ST_ERROR,(LPARAM)tpItemInfo);
        return CHECK_ERROR;
    }
    if(WSAGETSELECTERROR(lParam)){
        SetErrorMessage(tpItemInfo,WSAGETSELECTERROR(lParam));
        return CHECK_ERROR;
    }
    tpItemInfo->user1 = 0;
    switch(WSAGETSELECTEVENT(lParam)){
        case FD_READ:
            return SelectRecv(hWnd,tpItemInfo);
        default:
            break;
    }
    return CHECK_ERROR;
}

/*
 *  WSAAsyncGetHostByName�̌��ʂ���������n���h��
 */
__declspec(dllexport) int CALLBACK SNTP_Gethost(HWND hWnd,WPARAM wParam,LPARAM lParam,struct TPITEM *tpItemInfo)
{
    struct hostent *pHostEnt;
    unsigned long addr;
    struct TPSNTP *tpSNTP;

    if(tpItemInfo->hGetHost1 == NULL){
        SetErrorMessage(tpItemInfo,WSAGetLastError());
        SendMessage(hWnd,WM_CHECKEND,ST_ERROR,(LPARAM)tpItemInfo);
        return CHECK_ERROR;
    }
    tpItemInfo->hGetHost1 = NULL;

    tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;
    if(tpSNTP == NULL){
        return CHECK_ERROR;
    }
    if(WSAGETASYNCERROR(lParam)){
        SetErrorMessage(tpItemInfo,WSAGETSELECTERROR(lParam));
        return CHECK_ERROR;
    }
    pHostEnt = (struct hostent *)tpSNTP->HostEnt;
    addr = *((unsigned long *)((pHostEnt->h_addr_list)[0]));
    AddDNSCache(tpSNTP->szServer,addr);

    tpItemInfo->user1 = 0;
    if(WSAAsyncSelect(tpItemInfo->Soc1,hWnd,WM_WSOCK_SELECT,FD_READ) == SOCKET_ERROR){
        SetErrorMessage(tpItemInfo,WSAGetLastError());
        return CHECK_ERROR;
    }
    if(SendPacket(hWnd,tpItemInfo,addr,tpSNTP->nPort)){
        GetSystemTimeAsFileTime(&tpSNTP->ftSend);
        return CHECK_SUCCEED;
    }
    return CHECK_ERROR;
}

/*
 *  �N���b�v�{�[�h�p�̃e�L�X�g��Ԃ��n���h��
 */
__declspec(dllexport) HANDLE CALLBACK SNTP_GetItemText(struct TPITEM *tpItemInfo)
{
    HANDLE hMem;
    char *buf;
    int size;
    
    size = lstrlen(tpItemInfo->CheckURL);
    hMem = GlobalAlloc(GHND,size + 1);
    if(hMem == NULL){
        return NULL;
    }
    buf  = GlobalLock(hMem);
    if(buf == NULL){
        GlobalFree(hMem);
        return NULL;
    }
    lstrcpy(buf,tpItemInfo->CheckURL);
    GlobalUnlock(hMem);
    return hMem;
}

/*
 *  �`�F�b�N���I�������Ƃ��ɌĂ΂��R�[���o�b�N�B���\�[�X�̉�����s���B
 */
__declspec(dllexport) int CALLBACK SNTP_ItemCheckEnd(HWND hWnd,struct TPITEM *tpItemInfo)
{
    CloseSocket(hWnd,tpItemInfo);
    return 0;
}

/*
 *  �A�C�e�����j���[�ŃA�C�e���`�F�b�N�ȊO�̑���������֐�
 */
__declspec(dllexport) int CALLBACK SNTP_ExecItem(HWND hWnd,char *Action,struct TPITEM *tpItemInfo)
{
    if(lstrcmp(Action,"open") == 0){
        if(SNTP_Property(hWnd,tpItemInfo) == 0){
            // �A�C�e���̃v���p�e�B��OK�������ꂽ�Ƃ��B
            return 1;
        }
        return -1;
    }
    return 1;
}

/*
 *  �A�C�e�����j���[�ɒǉ����鍀�ڂ�ݒ肷��֐��B
 */
__declspec(dllexport) int CALLBACK SNTP_GetInfo(struct TPPROTOCOLINFO *tpInfo)
{
    int i = 0;

    lstrcpy(tpInfo->Scheme,"sntp://");
    lstrcpy(tpInfo->NewMenu,"SNTP�A�C�e���̒ǉ�(&S)...");
    lstrcpy(tpInfo->FileType,"");

    tpInfo->tpMenu = Malloc(sizeof(struct TPPROTOCOLMENU) * SNTP_MENU_CNT);
    tpInfo->tpMenuCnt = SNTP_MENU_CNT;

    lstrcpy(tpInfo->tpMenu[i].Name,"�J��(&O)");
    lstrcpy(tpInfo->tpMenu[i].Action,"open");
    tpInfo->tpMenu[i].Default = TRUE;
    tpInfo->tpMenu[i].Flag = 0;
    i++;
    return 0;
}

__declspec(dllexport) int CALLBACK SNTP_EndNotify(void)
{
    return 0;
}

__declspec(dllexport) int CALLBACK SNTP_ProtocolProperty(HWND hWnd)
{
    return 0;
}

