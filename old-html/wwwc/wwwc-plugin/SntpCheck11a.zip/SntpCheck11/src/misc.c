/*
 *  SntpCheck (WWWC�̃v���O�C��)
 *
 *  misc.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include "wwwcdll.h"

void *Malloc(int size)
{
    return GlobalAlloc(GPTR,size);
}

void *ReMalloc(void *p,int size)
{
    char *buf = Malloc(size);
    if(buf){
        CopyMemory(buf,p,lstrlen(p) + 1);
    }
    return buf;
}

void Free(void *buf)
{
    GlobalFree((HGLOBAL)buf);
}

char *GetServNameFromCheckURL(char *szURL)
{
    char *p;
    p = szURL;
    if(strnicmp(p,"sntp://",sizeof("sntp://")-1)==0){
        p += sizeof("sntp://")-1;
    }
    return p;
}

char * DupStr(char *buf)
{
    char *p;

    if(buf){
        p = Malloc(lstrlen(buf) + 1);
        if(p){
            lstrcpy(p,buf);
            return p;
        }
    }
    return NULL;
}


char * GetDlgEditText(HWND hDlg,int nID)
{
    char *buf = NULL;
    int bufsize = SendDlgItemMessage(hDlg,nID,WM_GETTEXTLENGTH,0,0);
    if(bufsize > 0){
        buf = Malloc(bufsize + 1);
        if(buf){
            GetDlgItemText(hDlg,nID,buf,bufsize + 1);
        }
    }
    return buf;
}

/*
 *  ���݂̎�����\����������擾����
 */
char *GetCurrentTimeString(void)
{
    SYSTEMTIME sys;
    char *p;

    GetLocalTime(&sys);

    p = Malloc(4 + 2 + 2 + 2 + 2 + 6);
    wsprintf(p,"%04d/%02d/%02d %02d:%02d",
             sys.wYear,sys.wMonth,sys.wDay,
             sys.wHour,sys.wMinute);
    return p;
}

/*
 * WWWC����Ԃ��ꂽ�o�[�W��������͂���
 * �����œn���ꂽ�������ύX���܂��B
 */
unsigned long ParseWWWCVersion(char *szVersion)
{
	char *p,*q;
	int major_version,sub_version;
	int minor_version,beta_version;

	q = szVersion;
	for(p = szVersion; *p != '\0' && *p != '.';p++);
	if(*p == '\0'){
		return 0;
	}
	*p = '\0';
	major_version = atoi(q);

	p++;
	for(q = p; *p != '\0' && *p != '.';p++);
	if(*p == '\0'){
		return 0;
	}
	*p = '\0';
	sub_version = atoi(q);

	p++;
	beta_version = 0;
	for(q = p; *p != '\0' && !isspace(*p) ;p++);
	if(*p == '\0'){
		minor_version = atoi(q);
	}
	else{
		*p = '\0';
		minor_version = atoi(q);

		p++;
		for(; *p != '\0' && !isdigit(*p) ;p++);

		beta_version = atoi(p);
	}

	return (major_version << 24) | (sub_version << 16) |
		   (minor_version <<  8) | (beta_version);

}

unsigned long GetWWWCVersion(HWND hwnd)
{
	char szVersion[32];

	/*
	 * "1.0.3 b1"
	 *  �擪����major_version, sub_version, minor_version, beta_version
	 *  ���ꂼ��̃o�[�W�������P�o�C�g����pack���ĕԂ��B
	 */
	SendMessage(hwnd, WM_GETVERSION, 0, (LPARAM)szVersion);
	return ParseWWWCVersion(szVersion);
}

/*
 * �g�p���Ă���WWWC�̃o�[�W�����Ɠ���̃o�[�W�������r����
 * �g�p���Ă���WWWC�̕����V�����Ƃ� 1
 *                       �����Ƃ�   0
 *                       �Â��Ƃ�  -1��Ԃ�
 *
 */
int CmpVersion(unsigned long Version,int major, int sub, int minor, int beta)
{
	unsigned long wwwc_version;
	unsigned long cmp_version;
	int wwwc_beta;

	wwwc_version = (Version >> 8);
	cmp_version  = (major << 16) | (sub << 8) | minor;
	if(wwwc_version > cmp_version){
		return 1;
	}
	else if(wwwc_version < cmp_version){
		return -1;
	}

	wwwc_beta = Version & 0xff;
	if(wwwc_beta == beta){
		return 0;
	}

	/* ���o�[�W�����́A0���ŐV */
	if(wwwc_beta == 0){
		return 1;
	}
	else if(beta == 0){
		return -1;
	}

	if(wwwc_beta > beta){
		return 1;
	}
	else if(wwwc_beta < beta){
		return -1;
	}
	return 0;
}


void DeleteReturn(char *buf)
{
	if(buf){
		for(;*buf;buf++){
			if(*buf == '\r'|| *buf == '\n' || *buf == '\t'){
				*buf = ' ';
			}
		}
	} 
}

