//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SntpCheck.rc
//
#define IDS_NOERROR                     0
#define IDS_TIMEOUT                     1
#define IDS_FAIL_ALLOC_MEMORY           2
#define IDS_REFUSE_CONNECT              3
#define IDS_HOST_NOT_FOUND              4
#define IDS_UNREACH_HOST                5
#define IDS_ADDRNOTAVAIL                6
#define IDI_ICON1                       100
#define IDD_DIALOG_PROP_GENERAL         101
#define IDD_DIALOG_PROP_OPTION          102
#define IDD_DIALOG_PROP_INFO            103
#define IDC_EDIT_TITLE                  1000
#define IDC_STATIC_STRATUM              1001
#define IDC_STATIC_VERSION              1002
#define IDC_STATIC_PRECISION            1003
#define IDC_STATIC_REFID                1005
#define IDC_EDIT_SERVER                 1006
#define IDC_STATIC_POLL                 1007
#define IDC_EDIT_COMMENT                1008
#define IDC_EDIT_PORT                   1009
#define IDC_STATIC_ERRTEXT              1011
#define IDC_CHECK_LIMIT                 1013
#define IDC_EDIT_LIMIT                  1014
#define IDC_SPIN_LIMIT                  1015
#define IDC_CHECK_NO_UPDATE             1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
