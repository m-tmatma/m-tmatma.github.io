/*
 *  dns.h
 *
 *  DNS�̃L���b�V���֘A�̃��W���[���B
 */
#ifndef _DNS_H_
#define _DNS_H_

void InitializeDNSCache(void);
void DestroyDNSCache(void);
void ClearDNSCache(void);

void AddDNSCache(char *szHost,unsigned long addr);
unsigned long GetDNSCache(char *szHost);
unsigned long GetHostAddr(char *szHost);

void DumpDNSCache(void);

#endif
