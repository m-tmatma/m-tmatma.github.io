/*
 *  SntpCheck (WWWC�̃v���O�C��)
 *
 *  error.h
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#ifndef _ERROR_H_
#define _ERROR_H_

void SetErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError);
void SetCustomErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError);

#endif //#ifndef _ERROR_H_

