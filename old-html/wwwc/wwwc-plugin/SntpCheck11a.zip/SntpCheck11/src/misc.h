/*
 *  SntpCheck (WWWC�̃v���O�C��)
 *
 *  misc.h
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#ifndef _MISC_H_
#define _MISC_H_

void *Malloc(int size);
void *ReMalloc(void *p,int size);

void Free(void *buf);
char *GetServNameFromCheckURL(char *szURL);
char *DupStr(char *buf);

char *GetDlgEditText(HWND hDlg,int nID);

char *GetCurrentTimeString(void);

void SetErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError);
void SetCustomErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError);

unsigned long GetWWWCVersion(HWND hwnd);
int CmpVersion(unsigned long Version,int major, int sub, int minor, int beta);
void DeleteReturn(char *buf);

#endif //#ifndef _MISC_H_
