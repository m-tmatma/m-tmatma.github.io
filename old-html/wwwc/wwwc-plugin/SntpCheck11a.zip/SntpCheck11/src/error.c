/*
 *  SntpCheck (WWWC�̃v���O�C��)
 *
 *  error.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include "wwwcdll.h"
#include "misc.h"
#include "error.h"

extern HINSTANCE g_hInst;

void SetErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError)
{
    LPVOID lpMsgBuf;

    if(tpItemInfo->ErrStatus){
        GlobalFree(tpItemInfo->ErrStatus);
        tpItemInfo->ErrStatus = NULL;
    }
    if(dwError == 0){
        return;
    }

    if(FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
                  FORMAT_MESSAGE_FROM_SYSTEM |
                  FORMAT_MESSAGE_MAX_WIDTH_MASK,
                  NULL,
                  dwError,
                  MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT),
                  (LPTSTR) &lpMsgBuf,0,NULL)){
    
        tpItemInfo->ErrStatus = DupStr(lpMsgBuf);
        LocalFree(lpMsgBuf);
    }
    else if(WSABASEERR <= dwError && dwError < WSABASEERR+2000){
        SetCustomErrorMessage(tpItemInfo,dwError);
    }
    else{
        tpItemInfo->ErrStatus = DupStr("���m�̃G���[�B");
    }
}

void SetCustomErrorMessage(struct TPITEM *tpItemInfo,DWORD dwError)
{
    char szMsg[1024];
    if(tpItemInfo->ErrStatus){
        GlobalFree(tpItemInfo->ErrStatus);
        tpItemInfo->ErrStatus = NULL;
    }
    if(LoadString(g_hInst,dwError,szMsg,sizeof(szMsg))){
        tpItemInfo->ErrStatus = DupStr(szMsg);
    }
    else{
        tpItemInfo->ErrStatus = DupStr("���m�̃G���[�B");
    }
}

