/*
 *	SntpCheck (WWWC�̃v���O�C��)
 *
 *	sntpprop.c
 *
 *	Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include <commctrl.h>
#include "wwwcdll.h"
#include "sntp.h"
#include "misc.h"
#include "option.h"
#include "resource.h"

extern HINSTANCE g_hInst;

int ParseServerInfo(struct TPITEM *tpItemInfo,struct NTP_Packet *pNtpPacket);

static BOOL CALLBACK SNTPProperty(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
static BOOL CALLBACK SNTPPropOption(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
static BOOL CALLBACK SNTPPropInfo(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);

static void InitItemProperty(HWND hDlg,struct TPITEM *tpItemInfo);
static void SaveItemProperty(HWND hDlg,struct TPITEM *tpItemInfo);
static void InitItemOptionProp(HWND hDlg,struct TPITEM *tpItemInfo);
static void SaveItemOptionProp(HWND hDlg,struct TPITEM *tpItemInfo);
static void InitItemInfoProp(HWND hDlg,struct TPITEM *tpItemInfo);

/*
 *	TPITEM�\���̂̃I�v�V�������������͂���֐�
 */
BOOL ParseParameter(struct TPITEM *tpItemInfo,struct TPSNTP *tpSNTP)
{
	if(tpItemInfo->CheckURL){
		char *p = GetServNameFromCheckURL(tpItemInfo->CheckURL);
		lstrcpy(tpSNTP->szServer,p);
		p = tpSNTP->szServer;

		// '/'����菜��
		while(*p && *p != '/'){
			p++;
		}
		if(*p){
			*p = '\0';
		}
	}
	else{
		lstrcpy(tpSNTP->szServer,"");
	}

	if(tpItemInfo->Option1){
		tpSNTP->nPort = GetOptionInt(tpItemInfo->Option1,INDEX_PORT);
		tpSNTP->bUseLimit = GetOptionInt(tpItemInfo->Option1,INDEX_USE_LIMIT);
		tpSNTP->nLimitTime= GetOptionInt(tpItemInfo->Option1,INDEX_LIMIT_TIME);
		tpSNTP->bNoUpdate = GetOptionInt(tpItemInfo->Option1,INDEX_NO_UPDATE);
	}
	else{
		struct servent *pSrv = getservbyname("sntp","udp");
		if(pSrv){
			tpSNTP->nPort = ntohs(pSrv->s_port);
		}
		else{
			tpSNTP->nPort = 123;
		}
		tpSNTP->bUseLimit  = FALSE;
		tpSNTP->nLimitTime = 0;
	}
	if(tpSNTP->nPort == 0){
		tpSNTP->nPort = 123;
	}
	return TRUE;
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u�̃_�C�A���O�v���[�V�W��
 */
static BOOL CALLBACK SNTPProperty(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	PROPSHEETPAGE *pPropSheet;
	struct TPITEM *tpItemInfo;
	NMHDR *nmhdr;

	switch (uMsg){
		case WM_INITDIALOG:
			pPropSheet = (PROPSHEETPAGE *)lParam;
			tpItemInfo = (struct TPITEM *)pPropSheet->lParam;
			InitItemProperty(hDlg,tpItemInfo);
			SetWindowLong(hDlg,DWL_USER,(long)tpItemInfo);
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch(nmhdr->code){
				case PSN_APPLY:
					tpItemInfo = (struct TPITEM *)GetWindowLong(hDlg,DWL_USER);
					if(tpItemInfo){
						SaveItemProperty(hDlg,tpItemInfo);
					}
					break;
				case PSN_QUERYCANCEL:
				case PSN_RESET:
				default:
					return FALSE;
			}
			SetWindowLong(hDlg,DWL_MSGRESULT,PSNRET_NOERROR);
			return TRUE;
			break;
		default:
			return FALSE;
	}
	return TRUE;

}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̃I�v�V�����^�u�̃_�C�A���O�v���[�V�W��
 */
static BOOL CALLBACK SNTPPropOption(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	PROPSHEETPAGE *pPropSheet;
	struct TPITEM *tpItemInfo;
	NMHDR *nmhdr;
	BOOL b;

	switch (uMsg){
		case WM_INITDIALOG:
			pPropSheet = (PROPSHEETPAGE *)lParam;
			tpItemInfo = (struct TPITEM *)pPropSheet->lParam;
			InitItemOptionProp(hDlg,tpItemInfo);
			SetWindowLong(hDlg,DWL_USER,(long)tpItemInfo);
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch(nmhdr->code){
				case PSN_APPLY:
					tpItemInfo = (struct TPITEM *)GetWindowLong(hDlg,DWL_USER);
					if(tpItemInfo){
						SaveItemOptionProp(hDlg,tpItemInfo);
					}
					break;
				case PSN_QUERYCANCEL:
				case PSN_RESET:
				default:
					return FALSE;
			}
			SetWindowLong(hDlg,DWL_MSGRESULT,PSNRET_NOERROR);
			return TRUE;
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam)){
				case IDC_CHECK_LIMIT:
					b = IsDlgButtonChecked(hDlg,IDC_CHECK_LIMIT);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LIMIT),b);
					break;
			}
			break;
		default:
			return FALSE;
	}
	return TRUE;

}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̏��^�u�̃_�C�A���O�v���[�V�W��
 */
static BOOL CALLBACK SNTPPropInfo(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	PROPSHEETPAGE *pPropSheet;
	struct TPITEM *tpItemInfo;

	switch (uMsg){
		case WM_INITDIALOG:
			pPropSheet = (PROPSHEETPAGE *)lParam;
			tpItemInfo = (struct TPITEM *)pPropSheet->lParam;
			SetWindowLong(hDlg,DWL_USER,(long)tpItemInfo);
			InitItemInfoProp(hDlg,tpItemInfo);
			break;
		default:
			return FALSE;
	}
	return TRUE;
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O��\������R�[���o�b�N�֐�
 */
__declspec(dllexport) int CALLBACK SNTP_Property(HWND hWnd,struct TPITEM *tpItemInfo)
{
	struct TPSNTP *tpSNTP = NULL;
	PROPSHEETPAGE psp;
	PROPSHEETHEADER psh;
	HPROPSHEETPAGE hpsp[3];
	int ret,count;
	char *szTitle;


	tpSNTP = Malloc(sizeof(struct TPSNTP));
	if(tpSNTP == NULL){
		return CHECK_ERROR;
	}
	tpSNTP->Version = GetWWWCVersion(hWnd);

	tpItemInfo->Param1 = (long)tpSNTP;
	ParseParameter(tpItemInfo,tpSNTP);

	psp.dwSize	  = sizeof(PROPSHEETPAGE);
	psp.dwFlags   = PSP_DEFAULT;
	psp.hInstance = g_hInst;

	count = 0;
	psp.pszTemplate = MAKEINTRESOURCE(IDD_DIALOG_PROP_GENERAL);
	psp.pfnDlgProc	= SNTPProperty;
	psp.lParam		= (LPARAM)tpItemInfo;
	hpsp[count++] = CreatePropertySheetPage(&psp);

	psp.pszTemplate = MAKEINTRESOURCE(IDD_DIALOG_PROP_OPTION);
	psp.pfnDlgProc	= SNTPPropOption;
	psp.lParam		= (LPARAM)tpItemInfo;
	hpsp[count++] = CreatePropertySheetPage(&psp);

	psp.pszTemplate = MAKEINTRESOURCE(IDD_DIALOG_PROP_INFO);
	psp.pfnDlgProc	= SNTPPropInfo;
	psp.lParam		= (LPARAM)tpItemInfo;
	hpsp[count++] = CreatePropertySheetPage(&psp);

	if(tpItemInfo->Title){
		szTitle = Malloc(6 * 2 + lstrlen(tpItemInfo->Title) + 1);
		if(szTitle){
			wsprintf(szTitle,"%s�̃v���p�e�B",tpItemInfo->Title);
		}
	}
	else{
		szTitle = Malloc(sizeof("�V�����A�C�e���̃v���p�e�B") + 1);
		if(szTitle){
			lstrcpy(szTitle,"�V�����A�C�e���̃v���p�e�B");
		}
	}
	memset(&psh,0,sizeof(PROPSHEETHEADER));
	psh.dwSize	   = sizeof(PROPSHEETHEADER);
	psh.dwFlags    = PSH_NOAPPLYNOW;
	psh.hInstance  = g_hInst;
	psh.hwndParent = hWnd;
	psh.pszCaption = szTitle;
	psh.nPages = count;
	psh.phpage = hpsp;
	psh.nStartPage = 0;

	ret = -1;
	if(PropertySheet(&psh) > 0){
		SaveOption(tpItemInfo,tpSNTP);
		ret = 0;
	}
	GlobalFree(szTitle);
	GlobalFree(tpSNTP);
	tpItemInfo->Param1 = 0;
	return ret;
}

/*
 * �R�����g�̓��͗��̃E�B���h�E�X�^�C����ݒ肷��
 */
void SetupComment(HWND hDlg, int nID, unsigned long Version)
{
	LONG Style;
	HWND hEditComment;

	hEditComment = GetDlgItem(hDlg, nID);
	Style = GetWindowLong( hEditComment, GWL_STYLE);

	switch(CmpVersion(Version, 1, 0, 3, 0)){
	case  0:
	case  1:
		Style |= (ES_MULTILINE | ES_WANTRETURN);
		break;
	case -1:
		Style &= ~(ES_WANTRETURN|ES_MULTILINE);
		break;
	}
	SetWindowLong( hEditComment, GWL_STYLE, Style);
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u������������֐�
 */
void InitItemProperty(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPSNTP *tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;

	if(tpItemInfo->Title){
		SetDlgItemText(hDlg,IDC_EDIT_TITLE,tpItemInfo->Title);
	}
	else{
		SetDlgItemText(hDlg,IDC_EDIT_TITLE,"�V�����A�C�e��");
	}

	if(tpItemInfo->ErrStatus && *tpItemInfo->ErrStatus){
		SetDlgItemText(hDlg,IDC_STATIC_ERRTEXT,tpItemInfo->ErrStatus);
	}
	else{
		SetDlgItemText(hDlg,IDC_STATIC_ERRTEXT,"�G���[�͂���܂���");
	}

	SetDlgItemText(hDlg,IDC_EDIT_SERVER,tpSNTP->szServer);
	SetDlgItemInt(hDlg,IDC_EDIT_PORT,tpSNTP->nPort,FALSE);
	if(tpItemInfo->Comment){
		SetDlgItemText(hDlg,IDC_EDIT_COMMENT,tpItemInfo->Comment);
	}
	SetupComment(hDlg, IDC_EDIT_COMMENT, tpSNTP->Version);

}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u�̐ݒ��ۑ�����֐�
 */
void SaveItemProperty(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPSNTP *tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;
	char *buf = NULL;
	char *p = NULL;

	// �^�C�g���̐ݒ�
	if(tpItemInfo->Title){
		GlobalFree(tpItemInfo->Title);
		tpItemInfo->Title = NULL;
	}
	tpItemInfo->Title = GetDlgEditText(hDlg,IDC_EDIT_TITLE);

	// �`�F�b�N����URL�̐ݒ�
	if(tpItemInfo->CheckURL){
		GlobalFree(tpItemInfo->CheckURL);
		tpItemInfo->CheckURL = NULL;
	}
	buf = GetDlgEditText(hDlg,IDC_EDIT_SERVER);
	if(buf){
		tpItemInfo->CheckURL = Malloc(lstrlen(buf) + sizeof("sntp://") + 1);
		wsprintf(tpItemInfo->CheckURL,"sntp://%s",buf);
		GlobalFree(buf);
		buf = NULL;
	}
	else{
		tpItemInfo->CheckURL = DupStr("sntp://");
	}

	tpSNTP->nPort = GetDlgItemInt(hDlg,IDC_EDIT_PORT,NULL,FALSE);

	// �R�����g�̐ݒ�
	if(tpItemInfo->Comment){
		GlobalFree(tpItemInfo->Comment);
		tpItemInfo->Comment = NULL;
	}

	tpItemInfo->Comment = GetDlgEditText(hDlg,IDC_EDIT_COMMENT);
	if(CmpVersion(tpSNTP->Version, 1, 0, 3, 0) < 0){
		/* ���s����̃R�����g���󂯕t����̂� ver 1.0.3�ȍ~*/
		DeleteReturn(tpItemInfo->Comment);
	}
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̃I�v�V�����^�u������������֐�
 */
void InitItemOptionProp(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPSNTP *tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;

	SendDlgItemMessage(hDlg,IDC_SPIN_LIMIT,UDM_SETRANGE,0,MAKELPARAM(30000,0));

	CheckDlgButton(hDlg,IDC_CHECK_LIMIT,tpSNTP->bUseLimit);
	CheckDlgButton(hDlg,IDC_CHECK_NO_UPDATE,tpSNTP->bNoUpdate);
	SendDlgItemMessage(hDlg,
					   IDC_SPIN_LIMIT,
					   UDM_SETPOS,
					   0,MAKELPARAM(tpSNTP->nLimitTime,0));
	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LIMIT),tpSNTP->bUseLimit);
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̃I�v�V�����^�u�̐ݒ��ۑ�����֐�
 */
void SaveItemOptionProp(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPSNTP *tpSNTP = (struct TPSNTP *)tpItemInfo->Param1;
	tpSNTP->bUseLimit = IsDlgButtonChecked(hDlg,IDC_CHECK_LIMIT);
	tpSNTP->nLimitTime= SendDlgItemMessage(hDlg,IDC_SPIN_LIMIT,UDM_GETPOS,0,0);
	tpSNTP->bNoUpdate = IsDlgButtonChecked(hDlg,IDC_CHECK_NO_UPDATE);
}

/*
 *	�ݒ��TPITEM�\���̂̃I�v�V����������ɕۑ�����֐�
 */
void SaveOption(struct TPITEM *tpItemInfo, struct TPSNTP *tpSNTP)
{
	if(tpItemInfo->Option1){
		GlobalFree(tpItemInfo->Option1);
		tpItemInfo->Option1 = NULL;
	}
	tpItemInfo->Option1 = Malloc(100);
	wsprintf(tpItemInfo->Option1,
			"%d;%d;%d;%d;",
			tpSNTP->nPort,
			tpSNTP->bUseLimit,
			tpSNTP->nLimitTime,
			tpSNTP->bNoUpdate);
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̃I�v�V�����^�u������������֐�
 */
void InitItemInfoProp(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct NTP_Packet packet;

	if(tpItemInfo->ErrStatus && *tpItemInfo->ErrStatus){
		return;
	}

	if(tpItemInfo->DLLData1){
		unsigned char buf[128];

		if(!ParseServerInfo(tpItemInfo,&packet)){
			return;
		}
		if(packet.Stratum != 0){
			SetDlgItemInt(hDlg,IDC_STATIC_STRATUM,packet.Stratum,FALSE);
			if(packet.Stratum == 1){
				wsprintf(buf,"%.4s",packet.RefID);
			}
			else{
				wsprintf(buf,"%d.%d.%d.%d",
					packet.RefID[0],
					packet.RefID[1],
					packet.RefID[2],
					packet.RefID[3]);
			}
			SetDlgItemText(hDlg,IDC_STATIC_REFID,buf);
		}

		SetDlgItemInt(hDlg,IDC_STATIC_VERSION,packet.Version,FALSE);
		if(packet.Precision < 0){
			if(packet.Precision >= -9){
				wsprintf(buf,"%d msec",1000 >> (-packet.Precision));
			}
			else if(packet.Precision >= -19){
				wsprintf(buf,"%d ��sec",1000000 >> (-packet.Precision));
			}
			else if(packet.Precision >= -29){
				wsprintf(buf,"%d nsec",1000000000 >> (-packet.Precision));
			}
			else{
				wsprintf(buf,"�s��");
			}
			SetDlgItemText(hDlg,IDC_STATIC_PRECISION,buf);
		}

		if(packet.Poll >= 0){
			wsprintf(buf,"%d sec",1 << packet.Poll);
		}
		else{
			wsprintf(buf,"%d msec",1000 >> (-packet.Poll));
		}
		SetDlgItemText(hDlg,IDC_STATIC_POLL,buf);		
	}
}



