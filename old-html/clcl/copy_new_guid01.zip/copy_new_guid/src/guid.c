/*
 * guidgen_tool
 *
 * guid.c
 *
 * Copyright (C) 2007 by Masaru Tsuchiyama
 * tsutsu@gmail.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef  _INC_OLE
#include <stdio.h>
#include "common.h"

#include "CLCLPlugin.h"

static void format_define_guid(
	TCHAR	*	szBuffer,
	int			size
)
{
	GUID guid = {0};
	CoCreateGuid( &guid );

	/*
	// {005CCDB7-C023-44d8-AE59-1FC65FEFC088}
	DEFINE_GUID(<<name>>, 
		0x5ccdb7, 0xc023, 0x44d8, 0xae, 0x59, 0x1f, 0xc6, 0x5f, 0xef, 0xc0, 0x88);
	*/
	sprintf( szBuffer, 
		"// {%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}\n"
		"DEFINE_GUID(<<name>>,\n"
		"\t0x%08X, 0x%04X, 0x%04X, 0x%02X, 0x%02X,"
		" 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X);\n",
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1],
		guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5],
		guid.Data4[6], guid.Data4[7],
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1],
		guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5],
		guid.Data4[6], guid.Data4[7]
	);
}

static void format_static_guid(
	TCHAR	*	szBuffer,
	int			size
)
{
	GUID guid = {0};
	CoCreateGuid( &guid );

	/*
	// {43EC3EAD-F936-43ac-9328-48041498FD62}
	static const GUID <<name>> = 
	{ 0x43ec3ead, 0xf936, 0x43ac, { 0x93, 0x28, 0x48, 0x4, 0x14, 0x98, 0xfd, 0x62 } };
	*/
	sprintf( szBuffer, 
		"// {%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}\n"
		"static const GUID <<name>> = \n"
		"{ 0x%08X, 0x%04X, 0x%04X,"
		" { 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X } "
		"};\n",
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1],
		guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5],
		guid.Data4[6], guid.Data4[7],
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1],
		guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5],
		guid.Data4[6], guid.Data4[7]
	);
}

void copy_format_guid(
	DATA_INFO	*	data_info,
	int				format_type
)
{
	const int size = 1024;
	TCHAR *ptr;

	if( !data_info ){
		return;
	}
	data_info->data = GlobalAlloc(GHND, size );
	data_info->size = size;

	ptr = GlobalLock(data_info->data);
	if( !ptr ){
		return;
	}
	switch( format_type ){
	case FORMATTYPE_DEFINEGUID:	format_define_guid( ptr, size ); break;
	case FORMATTYPE_STATICGUID:	format_static_guid( ptr, size ); break;
	}
	GlobalUnlock( data_info->data );
}
