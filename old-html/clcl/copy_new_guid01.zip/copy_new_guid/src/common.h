/*
 * guidgen_tool
 *
 * common.h
 *
 * Copyright (C) 2007 by Masaru Tsuchiyama
 * tsutsu@gmail.com
 */
#ifndef COMMON_H_
#define COMMON_H_

#define FORMATTYPE_DEFINEGUID	0
#define FORMATTYPE_STATICGUID	1

#include "CLCLPlugin.h"

void copy_format_guid(
	DATA_INFO	*	data_info,
	int				format_type
);
#endif
