/*
 * guidgen_tool
 *
 * main.c
 *
 * Copyright (C) 2007 by Masaru Tsuchiyama
 * tsutsu@gmail.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef  _INC_OLE

#include "CLCLPlugin.h"
#include "common.h"

/* Define */

/* Global Variables */
HINSTANCE hInst;

/* Local Function Prototypes */

/*
 * DllMain - ���C��
 */
int WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
	switch (fdwReason) {
	case DLL_PROCESS_ATTACH:
		hInst = hInstance;
		break;

	case DLL_PROCESS_DETACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}
	return TRUE;
}

/*
 * get_tool_info - �c�[�����擾
 */
__declspec(dllexport) BOOL CALLBACK get_tool_info(const HWND hWnd, const int index, TOOL_GET_INFO *tgi)
{
	switch (index) {
	case 0:
		lstrcpy(tgi->title, TEXT("GUID�̐���1 [DEFINE_GUID()]"));
		lstrcpy(tgi->func_name, TEXT("tool_define_guid0"));
		lstrcpy(tgi->cmd_line, TEXT(""));
		tgi->call_type = CALLTYPE_MENU | CALLTYPE_VIEWER;
		return TRUE;
	case 1:
		lstrcpy(tgi->title, TEXT("GUID�̐���2 [static const struct GUID = {...}]"));
		lstrcpy(tgi->func_name, TEXT("tool_define_guid1"));
		lstrcpy(tgi->cmd_line, TEXT(""));
		tgi->call_type = CALLTYPE_MENU | CALLTYPE_VIEWER;
		return TRUE;
	}
	return FALSE;
}

static int CALLBACK create_guid_string(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi,
	int format_type
)
{
	TCHAR data[MAX_PATH] = "DEFINE_GUID( <<TEST>>, 0x1234, 0x123f );\n";
	DATA_INFO *history_di;
	DATA_INFO *di;

	// �����̎擾
	if ((history_di = (DATA_INFO *)SendMessage(hWnd, WM_HISTORY_GET_ROOT, 0, 0)) == NULL) {
		return TOOL_SUCCEED;
	}

	// �A�C�e���̍쐬
	if ((di = (DATA_INFO *)SendMessage(hWnd, WM_ITEM_CREATE, TYPE_ITEM, 0)) == NULL) {
		return TOOL_CANCEL;
	}
	if ((di->child = (DATA_INFO *)SendMessage(hWnd, WM_ITEM_CREATE, TYPE_DATA, (LPARAM)TEXT("TEXT"))) == NULL) {
		SendMessage(hWnd, WM_ITEM_FREE, 0, (LPARAM)di);
		return TOOL_CANCEL;
	}

	copy_format_guid( di->child, format_type );
	SendMessage(hWnd, WM_ITEM_TO_CLIPBOARD, (WPARAM)0, (LPARAM)di->child);

	// �����ɒǉ�
	di->next = history_di->child;
	history_di->child = di;
	// �����̕ω���ʒm
	SendMessage(hWnd, WM_HISTORY_CHANGED, 0, 0);
	return TOOL_SUCCEED;
}

__declspec(dllexport) int CALLBACK tool_define_guid0(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi
)
{
	return create_guid_string( hWnd, tei, tdi, FORMATTYPE_DEFINEGUID );
}


__declspec(dllexport) int CALLBACK tool_define_guid1(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi
)
{
	return create_guid_string( hWnd, tei, tdi, FORMATTYPE_STATICGUID );
}

/* End of source */
