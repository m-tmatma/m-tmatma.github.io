/*
 * guidgen_tool
 *
 * common.h
 *
 * Copyright (C) 2007 by Masaru Tsuchiyama
 * m.tsutsu@gmail.com
 */
#ifndef COMMON_H_
#define COMMON_H_

#define FORMATTYPE_ZENKAKU	0
#define FORMATTYPE_CURLY	1
#define FORMATTYPE_SQUARE	2

#include "CLCLPlugin.h"

int item_convert_brackets(DATA_INFO *di, int format_type );
#endif
