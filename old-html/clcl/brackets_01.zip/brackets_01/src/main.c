/*
 * guidgen_tool
 *
 * main.c
 *
 * Copyright (C) 2007 by Masaru Tsuchiyama
 * tsutsu@gmail.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef  _INC_OLE

#include "CLCLPlugin.h"
#include "common.h"

/* Define */

/* Global Variables */
HINSTANCE hInst;

/* Local Function Prototypes */

/*
 * DllMain - ���C��
 */
int WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
	switch (fdwReason) {
	case DLL_PROCESS_ATTACH:
		hInst = hInstance;
		break;

	case DLL_PROCESS_DETACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}
	return TRUE;
}

/*
 * get_tool_info - �c�[�����擾
 */
__declspec(dllexport) BOOL CALLBACK get_tool_info(const HWND hWnd, const int index, TOOL_GET_INFO *tgi)
{
	switch (index) {
	case 0:
		lstrcpy(tgi->title, TEXT("�u�v������"));
		lstrcpy(tgi->func_name, TEXT("tool_brackets_zenkaku"));
		lstrcpy(tgi->cmd_line, TEXT(""));
		tgi->call_type = CALLTYPE_MENU | CALLTYPE_VIEWER;
		return TRUE;
	case 1:
		lstrcpy(tgi->title, TEXT("()������"));
		lstrcpy(tgi->func_name, TEXT("tool_brackets_curly"));
		lstrcpy(tgi->cmd_line, TEXT(""));
		tgi->call_type = CALLTYPE_MENU | CALLTYPE_VIEWER;
		return TRUE;
	case 2:
		lstrcpy(tgi->title, TEXT("[]������"));
		lstrcpy(tgi->func_name, TEXT("tool_brackets_square"));
		lstrcpy(tgi->cmd_line, TEXT(""));
		tgi->call_type = CALLTYPE_MENU | CALLTYPE_VIEWER;
		return TRUE;
	}
	return FALSE;
}

static int CALLBACK create_brackets_string(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi,
	int format_type
)
{
#if DEBUG
	DebugBreak();
#endif

	DATA_INFO *di;
	int ret = TOOL_SUCCEED;

	// �o�^�A�C�e������̂ݎ��s
	if ((tei->call_type & CALLTYPE_ITEM_TO_CLIPBOARD) && !(tei->call_type & CALLTYPE_REGIST)) {
		return TOOL_SUCCEED;
	}
	for (; tdi != NULL; tdi = tdi->next) {
		di = (DATA_INFO *)SendMessage(hWnd, WM_ITEM_GET_FORMAT_TO_ITEM, (WPARAM)TEXT("TEXT"), (LPARAM)tdi->di);
		if (di != NULL && di->data != NULL) {
			ret |= item_convert_brackets(di, format_type);
		}
	}
	return ret;
}

__declspec(dllexport) int CALLBACK tool_brackets_zenkaku(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi
)
{
	return create_brackets_string( hWnd, tei, tdi, FORMATTYPE_ZENKAKU );
}


__declspec(dllexport) int CALLBACK tool_brackets_curly(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi
)
{
	return create_brackets_string( hWnd, tei, tdi, FORMATTYPE_CURLY );
}


__declspec(dllexport) int CALLBACK tool_brackets_square(
	const HWND hWnd,
	TOOL_EXEC_INFO *tei,
	TOOL_DATA_INFO *tdi
)
{
	return create_brackets_string( hWnd, tei, tdi, FORMATTYPE_SQUARE );
}

/* End of source */
