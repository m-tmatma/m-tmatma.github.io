/*
 * bracket.c
 *
 * Copyright (C) 2010 by Masaru Tsuchiyama
 * m.tsutsu@gmail.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef  _INC_OLE
#include <stdio.h>
#include "common.h"

#include "CLCLPlugin.h"


int item_convert_brackets(DATA_INFO *di, int format_type )
{
	HANDLE ret;
	BYTE *from_mem, *to_mem;
	char *p;
	int size;

	// �R�s�[�����b�N
	if ((from_mem = GlobalLock(di->data)) == NULL) {
		return TOOL_ERROR;
	}

	p = from_mem;
	for( size = 0; *p != '\0'; size++, p++ )
	{
		;
	}
	size++;

	// �ϊ���T�C�Y�v�Z
	switch( format_type )
	{
	case FORMATTYPE_ZENKAKU:
		size += 2 * 2;
		break;
	case FORMATTYPE_CURLY:
	case FORMATTYPE_SQUARE:
		size += 2;
		break;
	}

	// �R�s�[��m��
	if ((ret = GlobalAlloc(GHND, size)) == NULL) {
		GlobalUnlock(di->data);
		return TOOL_ERROR;
	}
	// �R�s�[�惍�b�N
	if ((to_mem = GlobalLock(ret)) == NULL) {
		GlobalFree(ret);
		GlobalUnlock(di->data);
		return TOOL_ERROR;
	}

	// �ϊ���T�C�Y�v�Z
	switch( format_type )
	{
	case FORMATTYPE_ZENKAKU:
		sprintf( to_mem, "�u%s�v", from_mem );
		break;
	case FORMATTYPE_CURLY:
		sprintf( to_mem, "(%s)", from_mem );
		break;
	case FORMATTYPE_SQUARE:
		sprintf( to_mem, "[%s]", from_mem );
		break;
	}

	GlobalUnlock(ret);
	GlobalUnlock(di->data);

	GlobalFree(di->data);
	di->data = ret;
	di->size = size;
	return TOOL_DATA_MODIFIED;
}
