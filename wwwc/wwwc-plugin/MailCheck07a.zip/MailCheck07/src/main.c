/*
 *  MailCheck (WWWC�̃v���O�C��)
 *
 *  main.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include <commctrl.h>
#include "wwwcdll.h"

HINSTANCE g_hInst;

int WINAPI DllMain(HINSTANCE hInst, DWORD fdwReason, PVOID pvReserved)
{
	g_hInst = hInst;
	InitCommonControls();

	return TRUE;
}

__declspec(dllexport) int CALLBACK GetProtocolList(int cnt, struct TPPROTOCOLSET *tpProtocolSet)
{
	int ret = 0;

	switch(cnt){
		case 0:
			lstrcpy(tpProtocolSet->Title, "POP3");
			lstrcpy(tpProtocolSet->FuncHeader, "POP3_");
			lstrcpy(tpProtocolSet->IconFile, "");
			tpProtocolSet->IconIndex = 0;
			lstrcpy(tpProtocolSet->UpIconFile, "");
			tpProtocolSet->UpIconIndex = -1;
			break;
		default:
			ret = -1;
			break;
	}
	return ret;
}

__declspec(dllexport) int CALLBACK GetToolList(int cnt, struct TP_TOOLS *tpToolInfo)
{
	int ret = 0;

	switch(cnt){
		default:
			ret = -1;
			break;
	}
	return ret;
}

