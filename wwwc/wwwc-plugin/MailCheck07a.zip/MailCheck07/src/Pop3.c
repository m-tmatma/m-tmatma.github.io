/*
 *  MailCheck (WWWC�̃v���O�C��)
 *
 *  pop3.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "wwwcdll.h"
#include "dns.h"
#include "Pop3.h"
#include "error.h"
#include "global.h"
#include "md5.h"
#include "resource.h"

//#define NO_SUPPORT_LAST
//#define NO_SUPPORT_UIDL
//#define NO_SUPPORT_TOP

extern HINSTANCE g_hInst;

static void CloseSocket(HWND hWnd, struct TPITEM *tpItemInfo);
static int Connect(HWND hWnd,struct TPITEM *tpItemInfo,unsigned long addr);
static BOOL ConnectServer(int cSoc, unsigned long cIPaddr, int nPort);
static int SelectRecv(HWND hWnd,struct TPITEM *tpItemInfo);
static int ParseRecvData(HWND hWnd,struct TPITEM *tpItemInfo,struct TPPOP3 *tpPOP3);

static int SendQUIT(int soc);
static int SendSTAT(int soc);
static int SendLAST(int soc);
static int SendTop(int soc,int num);
static int SendAPOP(int soc,char *szUser,char *szPass,char *szTimeStamp);
static int SendUser(int soc,char *szUser);
static int SendPass(int soc,char *szPass);
static int Send(int soc,char *buf);
static int SendUIDL(int soc,int num);
static int SelectClose(HWND hWnd,struct TPITEM *tpItemInfo);
static void ParseGreeting(struct TPPOP3 * tpPOP3);
static char *GetCurrentTimeString(void);
static char * CalcMessageDigest(char *buf);

/*
 * WWWC�̃X�e�[�^�X�o�[�Ƀe�L�X�g��\������֐�
 */
int SetStatusBar(HWND hWnd,char *format,...)
{
	va_list va_arg;
	int n = 0;
	char *buf = NULL;

	buf = Malloc(8 * 1024);
	if(buf){
		va_start(va_arg,format);
		n = vsprintf(buf,format,va_arg);
		va_end(va_arg);
		SendMessage(GetDlgItem(hWnd, WWWC_SB),SB_SETTEXT,(WPARAM)0,(LPARAM)buf);
		Free(buf);
	}
	return n;
}

/*
 *	�A�C�R�����������Ƃ��ɌĂ΂��֐�
 */
__declspec(dllexport) int CALLBACK POP3_FreeItem(struct TPITEM *tpItemInfo)
{
	if(tpItemInfo->Param1){
		struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
		if(tpPOP3->szBuf){
			GlobalFree(tpPOP3->szBuf);
			tpPOP3->szBuf = NULL;
		}
		if(tpPOP3->szTimeStamp){
			GlobalFree(tpPOP3->szTimeStamp);
			tpPOP3->szTimeStamp = NULL;
		}
		if(tpPOP3->szUIDL){
			GlobalFree(tpPOP3->szUIDL);
			tpPOP3->szUIDL = NULL;
		}
		GlobalFree(tpPOP3);
		tpItemInfo->Param1 = 0;
	}
	return 0;
}

/*
 *	�A�C�R��������������Ƃ��ɌĂ΂��
 */
__declspec(dllexport) int CALLBACK POP3_InitItem(HWND hWnd, struct TPITEM *tpItemInfo)
{
	if(tpItemInfo->ErrStatus != NULL){
		GlobalFree(tpItemInfo->ErrStatus);
		tpItemInfo->ErrStatus = NULL;
	}
	if((tpItemInfo->Status & ST_UP) == 0){
		/* �X�V�}�[�N(*)���������� */
		if(tpItemInfo->Size != NULL && *tpItemInfo->Size != '\0' &&
			*(tpItemInfo->Size + lstrlen(tpItemInfo->Size) - 1) == '*'){
			*(tpItemInfo->Size + lstrlen(tpItemInfo->Size) - 1) = '\0';
		}
		if(tpItemInfo->Date != NULL && *tpItemInfo->Date != '\0' &&
			*(tpItemInfo->Date + lstrlen(tpItemInfo->Date) - 1) == '*'){
			*(tpItemInfo->Date + lstrlen(tpItemInfo->Date) - 1) = '\0';
		}
	}
	return 0;
}

/*
 *	�`�F�b�N�J�n�̂Ƃ��ɃA�C�e�������������邽�߂ɌĂ΂��֐��B
 */
__declspec(dllexport) int CALLBACK POP3_Initialize(HWND hWnd, struct TPITEM *tpItemInfo)
{
	if(tpItemInfo->ErrStatus){
		GlobalFree(tpItemInfo->ErrStatus);
		tpItemInfo->ErrStatus = NULL;
	}
	tpItemInfo->user1 = 0;
	tpItemInfo->user2 = 0;
	return 0;
}

/*
 *	�`�F�b�N�𒆎~����֐�
 */
__declspec(dllexport) int CALLBACK POP3_Cancel(HWND hWnd, struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	if(tpPOP3){
		tpPOP3->bMultiLine = FALSE;
		tpPOP3->state = POP3_QUIT;
		SendQUIT(tpItemInfo->Soc1);
	}
	return 0;
}

/*
 *	1�b���ƂɌĂ΂��֐��B�A�C�e���`�F�b�N�̃^�C���A�E�g����������B
 */
__declspec(dllexport) int CALLBACK POP3_Timer(HWND hWnd, struct TPITEM *tpItemInfo)
{
	if(tpItemInfo->user1 == -1){
		return CHECK_SUCCEED;
	}
	tpItemInfo->user1++;

	if(tpItemInfo->user1 >= TIMEOUT){
		tpItemInfo->user1 = -1;
		SetErrorMessage(tpItemInfo,WSAETIMEDOUT);
		SendMessage(hWnd,WM_CHECKEND, ST_TIMEOUT, (LPARAM)tpItemInfo);
		return CHECK_END;
	}
	return CHECK_SUCCEED;
}

/*
 *	�A�C�e���̃`�F�b�N���J�n����֐�
 */
__declspec(dllexport) int CALLBACK POP3_Start(HWND hWnd, struct TPITEM *tpItemInfo)
{
	unsigned long addr;
	struct TPPOP3 *tpPOP3;

	if(tpItemInfo->Param1 == 0){
		tpPOP3 = Malloc(sizeof(struct TPPOP3));
		if(tpPOP3 == NULL){
			SetCustomErrorMessage(tpItemInfo,IDS_FAIL_ALLOC_MEMORY);
			return CHECK_ERROR;
		}
		tpItemInfo->user1 = 0;
		tpItemInfo->Param1 = (long)tpPOP3;
		ParseParameter(tpItemInfo,tpPOP3);
	}
	tpPOP3->szBuf = Malloc(RECV_BUFSIZE);
	tpPOP3->nBufSize = RECV_BUFSIZE;
	tpPOP3->nDataSize= 0;
	
	SetStatusBar(hWnd,"%s�ɐڑ���...",tpPOP3->szServer);

	addr = inet_addr(tpPOP3->szServer);
	if(addr == -1){
		addr = GetDNSCache(tpPOP3->szServer);
	}
	if(addr == -1){
		SetStatusBar(hWnd,"IP�A�h���X���擾��(%s)...",tpPOP3->szServer);

		memset(tpPOP3->HostEnt,0,MAXGETHOSTSTRUCT);
		tpItemInfo->hGetHost1 = WSAAsyncGetHostByName(hWnd,
													  WM_WSOCK_GETHOST,
													  tpPOP3->szServer,
													  tpPOP3->HostEnt,
													  MAXGETHOSTSTRUCT);
		if(tpItemInfo->hGetHost1 == NULL){
			tpItemInfo->user1 = -1;
			SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
			return CHECK_ERROR;
		}
		return CHECK_SUCCEED;
	}
	return Connect(hWnd,tpItemInfo,addr);
}

/*
 *	Select�C�x���g�n���h��
 */
__declspec(dllexport) int CALLBACK POP3_Select(HWND hWnd, WPARAM wParam, LPARAM lParam, struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3;
	DWORD dwError;

	tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	if(tpPOP3 == NULL){
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		SetCustomErrorMessage(tpItemInfo,IDS_FAIL_ALLOC_MEMORY);
		return CHECK_ERROR;
	}
	dwError = WSAGETSELECTERROR(lParam);
	if(dwError){
		SetErrorMessage(tpItemInfo,dwError);
		return CHECK_ERROR;
	}
	tpItemInfo->user1 = 0;
	switch(WSAGETSELECTEVENT(lParam)){
		case FD_CONNECT:
			tpPOP3->state = POP3_CONNECT;
			return CHECK_SUCCEED;
		case FD_READ:
			return SelectRecv(hWnd,tpItemInfo);
		case FD_CLOSE:
			return SelectClose(hWnd,tpItemInfo);
	}
	return CHECK_ERROR;
}

/*
 *	WSAAsyncGetHostByName�̌��ʂ���������n���h��
 */
__declspec(dllexport) int CALLBACK POP3_Gethost(HWND hWnd, WPARAM wParam, LPARAM lParam, struct TPITEM *tpItemInfo)
{
	struct hostent *pHostEnt;
	unsigned long addr;
	struct TPPOP3 *tpPOP3;
	DWORD dwError;

	dwError = WSAGETASYNCERROR(lParam);
	if(tpItemInfo->hGetHost1 == NULL || dwError){
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		SetErrorMessage(tpItemInfo,dwError);
		return CHECK_ERROR;
	}
	tpItemInfo->hGetHost1 = NULL;

	tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	if(tpPOP3 == NULL){
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		SetCustomErrorMessage(tpItemInfo,IDS_FAIL_ALLOC_MEMORY);
		return CHECK_ERROR;
	}

	pHostEnt = (struct hostent *)tpPOP3->HostEnt;
	addr = *((unsigned long *)((pHostEnt->h_addr_list)[0]));
	AddDNSCache(tpPOP3->szServer,addr);

	tpItemInfo->user1 = 0;
	return Connect(hWnd,tpItemInfo,addr);
}

/*
 *	�N���b�v�{�[�h�p�̃e�L�X�g��Ԃ��n���h��
 */
__declspec(dllexport) HANDLE CALLBACK POP3_GetItemText(struct TPITEM *tpItemInfo)
{
	HANDLE hMem;
	char *buf;
	int size;
	
	size = lstrlen(tpItemInfo->CheckURL);
	hMem = GlobalAlloc(GHND,size + 1);
	if(hMem == NULL){
		return NULL;
	}
	buf  = GlobalLock(hMem);
	if(buf == NULL){
		GlobalFree(hMem);
		return NULL;
	}
	lstrcpy(buf,tpItemInfo->CheckURL);
	GlobalUnlock(hMem);
	return hMem;
}

/*
__declspec(dllexport) BOOL CALLBACK POP3_CreateDropItem(struct TPITEM *tpItemInfo, char *fPath, char *iPath, char *ret)
{}
__declspec(dllexport) int CALLBACK POP3_DropFile(HWND hWnd, char *FileType, char *FilePath, struct TPITEM *tpItemInfo)
{}
*/

/*
 *	�`�F�b�N���I�������Ƃ��ɌĂ΂��R�[���o�b�N�B���\�[�X�̉�����s���B
 */
__declspec(dllexport) int CALLBACK POP3_ItemCheckEnd(HWND hWnd,struct TPITEM *tpItemInfo)
{
	CloseSocket(hWnd,tpItemInfo);
	return 0;
}

/*
 *	�A�C�e�����j���[�ŃA�C�e���`�F�b�N�ȊO�̑���������֐�
 */
__declspec(dllexport) int CALLBACK POP3_ExecItem(HWND hWnd, char *Action, struct TPITEM *tpItemInfo)
{
	if(lstrcmp(Action,"open") == 0){
		STARTUPINFO si;
		PROCESS_INFORMATION pi;

		if(tpItemInfo->DLLData1 && *tpItemInfo->DLLData1){
			ZeroMemory(&si,sizeof(STARTUPINFO));
			ZeroMemory(&pi,sizeof(PROCESS_INFORMATION));
			si.cb = sizeof(STARTUPINFO);
			si.dwFlags = STARTF_USESHOWWINDOW;
			si.wShowWindow = SW_SHOWNORMAL;
			if(!CreateProcess(NULL,tpItemInfo->DLLData1,
							  NULL,NULL,FALSE,0,0,NULL,&si,&pi)){
				MessageBox(hWnd,"���[���[���N���ł��܂���ł���","MailCheck",MB_ICONWARNING);
				return -1;
			}
			CloseHandle(pi.hProcess);
		}
		else{
			MessageBox(hWnd,"���[���[���ݒ肳��Ă��܂���","MailCheck",MB_ICONWARNING);
			return -1;
		}
	}
	return 1;
}

/*
 *	�A�C�e�����j���[�ɒǉ����鍀�ڂ�ݒ肷��֐��B
 */
__declspec(dllexport) int CALLBACK POP3_GetInfo(struct TPPROTOCOLINFO *tpInfo)
{
	int i = 0;

	lstrcpy(tpInfo->Scheme, "pop://");
	lstrcpy(tpInfo->NewMenu, "���[���A�C�e���̒ǉ�(&M)...");
	lstrcpy(tpInfo->FileType, "");

	tpInfo->tpMenu = Malloc(sizeof(struct TPPROTOCOLMENU) * POP3_MENU_CNT);
	tpInfo->tpMenuCnt = POP3_MENU_CNT;

	lstrcpy(tpInfo->tpMenu[i].Name, "�J��(&O)");
	lstrcpy(tpInfo->tpMenu[i].Action, "open");
	tpInfo->tpMenu[i].Default = TRUE;
	tpInfo->tpMenu[i].Flag = 0;
	i++;
	return 0;
}

__declspec(dllexport) int CALLBACK POP3_EndNotify(void)
{
	DestroyDNSCache();
	return 0;
}

__declspec(dllexport) int CALLBACK POP3_ProtocolProperty(HWND hWnd)
{
	return 0;
}

static void CloseSocket(HWND hWnd, struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	int n;

	if(tpPOP3){
		WSAAsyncSelect(tpItemInfo->Soc1, hWnd, 0, 0);
		while((n = recv(tpItemInfo->Soc1,tpPOP3->szBuf,tpPOP3->nBufSize - 1, 0)) > 0 ){
			;
		}
		if(tpItemInfo->hGetHost1){
			WSACancelAsyncRequest(tpItemInfo->hGetHost1);
			tpItemInfo->hGetHost1 = NULL;
		}
		if(tpItemInfo->Param1){
			if(tpPOP3->szBuf){
				GlobalFree((HGLOBAL)tpPOP3->szBuf);
				tpPOP3->szBuf = NULL;
			}
			if(tpPOP3->szTimeStamp){
				GlobalFree((HGLOBAL)tpPOP3->szTimeStamp);
				tpPOP3->szTimeStamp = NULL;
			}
			if(tpPOP3->szUIDL){
				GlobalFree((HGLOBAL)tpPOP3->szUIDL);
				tpPOP3->szUIDL = NULL;
			}
			GlobalFree(tpPOP3);
			tpItemInfo->Param1 = 0;
		}
	}

	//�\�P�b�g�����
	if(tpItemInfo->Soc1 != -1){
		shutdown(tpItemInfo->Soc1,2);
		closesocket(tpItemInfo->Soc1);
		tpItemInfo->Soc1 = -1;
	}
}

static BOOL ConnectServer(int cSoc, unsigned long cIPaddr, int nPort)
{
	struct sockaddr_in saServer;

	/* �T�[�o��IP�A�h���X�ƃ|�[�g�ԍ���ݒ� */
	saServer.sin_family = AF_INET;
	saServer.sin_addr.s_addr = cIPaddr;
	saServer.sin_port = htons((unsigned short)nPort);
	memset(saServer.sin_zero,0,sizeof(saServer.sin_zero));

	/* �T�[�o�ɐڑ����� */
	if(connect(cSoc,(struct sockaddr *)&saServer,sizeof(saServer)) == SOCKET_ERROR){
		if(WSAGetLastError() != WSAEWOULDBLOCK){
			return FALSE;
		}
	}
	return TRUE;
}

static int Connect(HWND hWnd,struct TPITEM *tpItemInfo,unsigned long addr)
{
	struct TPPOP3 *tpPOP3;

	tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	tpItemInfo->Soc1 = socket(AF_INET, SOCK_STREAM, 0);
	if(tpItemInfo->Soc1 == INVALID_SOCKET){
		SetErrorMessage(tpItemInfo,WSAGetLastError());
		return CHECK_ERROR;
	}
	if(WSAAsyncSelect(tpItemInfo->Soc1,
					  hWnd,WM_WSOCK_SELECT,
					  FD_CONNECT|FD_READ|FD_CLOSE) == SOCKET_ERROR){
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		SetErrorMessage(tpItemInfo,WSAGetLastError());
		return CHECK_ERROR;
	}
	
	if(ConnectServer(tpItemInfo->Soc1, addr, tpPOP3->nPort) == FALSE){
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		SetErrorMessage(tpItemInfo,WSAGetLastError());
		return CHECK_ERROR;
	}
	return CHECK_SUCCEED;
}


static int SelectRecv(HWND hWnd,struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3;
	int n;
	char *p;

	tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	if(tpPOP3 == NULL){
		return CHECK_ERROR;
	}
	p = tpPOP3->szBuf + tpPOP3->nDataSize;
	
	n = recv(tpItemInfo->Soc1,p,tpPOP3->nBufSize-tpPOP3->nDataSize-1, 0);
	if(n == SOCKET_ERROR){
		tpItemInfo->user1 = -1;
		SendMessage(hWnd,WM_CHECKEND, ST_ERROR, (LPARAM)tpItemInfo);
		return CHECK_ERROR;
	}
	*(p+n) = '\0';
	tpPOP3->nDataSize += n;

	// �������������ς��̂Ƃ����������m�ۂ���
	if(tpPOP3->nDataSize + 2 >= tpPOP3->nBufSize){
		char *buf = NULL;
		tpPOP3->nBufSize += RECV_BUFSIZE;
		buf = ReMalloc(tpPOP3->szBuf,tpPOP3->nBufSize);
		if(tpPOP3->szBuf){
			GlobalFree(tpPOP3->szBuf);
		}
		if(buf == NULL){
			SetCustomErrorMessage(tpItemInfo,IDS_FAIL_ALLOC_MEMORY);
			return CHECK_ERROR;
		}
		tpPOP3->szBuf = buf;
	}
	return ParseRecvData(hWnd,tpItemInfo,tpPOP3);
}

char * GetEndOfMultiLine(char *buf)
{
	return strstr(buf,"\r\n.\r\n");
}

char * GetLine(char *buf,char *line)
{
	char *p = buf;
	char *q = line;
	for(;*p && *p != '\r' && *p != '\n';){
		*q++ = *p++;
	}
	*q = '\0';
	for(;*p && (*p == '\r' || *p == '\n');p++);
	return p;
}

int ParseRecvData(HWND hWnd,struct TPITEM *tpItemInfo,struct TPPOP3 *tpPOP3)
{
	char szTmp[1024];
	int ret = 1;
	int Status = ST_DEFAULT;
	BOOL bRetCode = TRUE;
	char *p;

	if(tpPOP3->bMultiLine && *tpPOP3->szBuf=='+'){
		if(GetEndOfMultiLine(tpPOP3->szBuf) == NULL){
			// Multi-Line Response�̏I�[���Ȃ��Ƃ��͎�M�𑱂���
			return CHECK_SUCCEED;
		}
	}
	else{
		if(strchr(tpPOP3->szBuf,'\n')==NULL){
			return CHECK_SUCCEED;
		}
	}

	switch(tpPOP3->state){
		case POP3_CONNECT:
			SetStatusBar(hWnd,"%s�ɐڑ����܂���",tpPOP3->szServer);

			ParseGreeting(tpPOP3);
			tpPOP3->nMail = -1;
			tpPOP3->nReadMail = -1;

			if(tpPOP3->bUseAPOP){
				if(tpPOP3->szTimeStamp == NULL){
					SetCustomErrorMessage(tpItemInfo,IDS_NOT_SUPPORT_APOP);
					bRetCode = FALSE;
					break;
				}
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_APOP;
				ret = SendAPOP(tpItemInfo->Soc1,
							   tpPOP3->szUser,
							   tpPOP3->szPass,
							   tpPOP3->szTimeStamp);
			}
			else{
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_USER;
				ret = SendUser(tpItemInfo->Soc1,tpPOP3->szUser);
			}
			break;
		case POP3_APOP:
			if(*tpPOP3->szBuf=='+'){
				SetStatusBar(hWnd,"���O�C�����܂���(���[�UID %s)...",tpPOP3->szUser);

				tpPOP3->nDataSize = 0;
				if(tpPOP3->szUser == NULL || tpPOP3->szPass == NULL){
					SetCustomErrorMessage(tpItemInfo,IDS_WRONG_PASS);
					bRetCode = FALSE;
					break;
				}
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_STAT;
				SetStatusBar(hWnd,"���[���̐��𒲂ׂĂ��܂�(%s)...",tpPOP3->szServer);

				ret = SendSTAT(tpItemInfo->Soc1);
			}
			else{
				SetCustomErrorMessage(tpItemInfo,IDS_WRONG_PASS);
				bRetCode = FALSE;
			}
			break;
		case POP3_USER:
			if(*tpPOP3->szBuf=='+'){
				tpPOP3->nDataSize = 0;
				if(tpPOP3->szPass == NULL){
					SetCustomErrorMessage(tpItemInfo,IDS_WRONG_PASS);
					bRetCode = FALSE;
					break;
				}
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_PASS;
				ret = SendPass(tpItemInfo->Soc1,tpPOP3->szPass);
			}
			else{
				SetCustomErrorMessage(tpItemInfo,IDS_WRONG_USER);
				bRetCode = FALSE;
			}
			break;
		case POP3_PASS:
			if(*tpPOP3->szBuf=='+'){
				SetStatusBar(hWnd,"���O�C�����܂���(���[�UID %s)...",tpPOP3->szUser);

				tpPOP3->nDataSize = 0;
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_STAT;
				SetStatusBar(hWnd,"���[���̐��𒲂ׂĂ��܂�(%s)...",tpPOP3->szServer);

				ret = SendSTAT(tpItemInfo->Soc1);
			}
			else{
				SetCustomErrorMessage(tpItemInfo,IDS_WRONG_PASS);
				bRetCode = FALSE;
			}
			break;
		case POP3_STAT:
			if(*tpPOP3->szBuf=='+'){
				sscanf(tpPOP3->szBuf,"%s %d",szTmp,&tpPOP3->nMail);
				tpPOP3->nDataSize = 0;
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_LAST;
				SetStatusBar(hWnd,"���ǃ��[���̐��𒲂ׂĂ��܂�(%s)...",tpPOP3->szServer);

				ret = SendLAST(tpItemInfo->Soc1);
			}
			else{
				bRetCode = FALSE;
			}
			break;
		case POP3_LAST:
			if(*tpPOP3->szBuf=='+'){
				sscanf(tpPOP3->szBuf,"%s %d",szTmp,&tpPOP3->nReadMail);

				// �Ō�̃��[����UIDL���擾����
				if(tpPOP3->nMail > 0){
					tpPOP3->state = POP3_UIDL;
					tpPOP3->bMultiLine = FALSE;
					SetStatusBar(hWnd,"�Ō�̃��[���𒲂ׂĂ��܂�(%s)...",tpPOP3->szServer);
					ret = SendUIDL(tpItemInfo->Soc1,tpPOP3->nMail);
				}
				else{
					tpPOP3->nReadMail = 0;
					tpPOP3->state = POP3_QUIT;
					tpPOP3->bMultiLine = FALSE;
					ret = SendQUIT(tpItemInfo->Soc1);
				}
			}
			else{
				tpPOP3->state = POP3_UIDL;
				tpPOP3->bMultiLine = TRUE;
				SetStatusBar(hWnd,"���ǃ��[���̐��𒲂ׂĂ��܂�(UIDL)(%s)...",tpPOP3->szServer);
				ret = SendUIDL(tpItemInfo->Soc1,-1);
			}
			break;
		case POP3_UIDL:
			if(tpPOP3->bMultiLine){
				if(*tpPOP3->szBuf=='+'){
					char **ppUIDLs,**pp;
					char szUIDL[512];
					int i,n;

					pp = ppUIDLs = Malloc(sizeof(char *) * (tpPOP3->nMail + 1));

					// ���X�|���X��ǂݎ̂Ă�
					p = GetLine(tpPOP3->szBuf,szTmp);

					// UIDL����荞��
					while(*p && strncmp(p,".\r\n",3) != 0){
						p = GetLine(p,szTmp);
						sscanf(szTmp,"%d %s",&n,szUIDL);
						*pp = DupStr(szUIDL);
						pp++;
					}
					if(tpItemInfo->DLLData2){
						// �O��A�N�Z�X�����Ƃ��̍Ō�̃��[�������݂�
						// ���[���{�b�N�X�ɂ��邩���ׂ�
						for(i=1,pp = ppUIDLs;*pp;pp++,i++){
							if(lstrcmp(tpItemInfo->DLLData2,*pp)==0){
								break;
							}
						}
						// �O��̍Ō�̃��[���܂ł����ǃ��[���Ƃ���B
						if(*pp){
							tpPOP3->nReadMail = i;
						}
						else{
							tpPOP3->nReadMail = 0;
						}
					}
					if(tpPOP3->nMail > 0){
						// �Ō�̃��[����UIDL��ۑ�����
						if(tpPOP3->szUIDL){
							GlobalFree(tpPOP3->szUIDL);
							tpPOP3->szUIDL = NULL;
						}
						tpPOP3->szUIDL = DupStr(ppUIDLs[tpPOP3->nMail-1]);
					}
					for(pp=ppUIDLs;*pp;pp++){
						GlobalFree(*pp);
					}
					GlobalFree(ppUIDLs);

					tpPOP3->bMultiLine = FALSE;
					tpPOP3->state = POP3_QUIT;
					ret = SendQUIT(tpItemInfo->Soc1);
				}
				else{
					tpPOP3->bMultiLine = TRUE;
					tpPOP3->state = POP3_TOP;
					ret = SendTop(tpItemInfo->Soc1,tpPOP3->nMail);
				}
			}
			else{
				if(*tpPOP3->szBuf=='+'){
					int n;
					if(tpPOP3->szUIDL == NULL){
						tpPOP3->szUIDL = Malloc(256);
					}
					sscanf(tpPOP3->szBuf,"%s %d %s",szTmp,&n,tpPOP3->szUIDL);

					tpPOP3->bMultiLine = FALSE;
					tpPOP3->state = POP3_QUIT;
					ret = SendQUIT(tpItemInfo->Soc1);
				}
				else{
					tpPOP3->bMultiLine = TRUE;
					tpPOP3->state = POP3_TOP;
					ret = SendTop(tpItemInfo->Soc1,tpPOP3->nMail);
				}
			}
			break;
		case POP3_TOP:
			if(*tpPOP3->szBuf=='+'){
				p = GetLine(tpPOP3->szBuf,szTmp);
				if(tpPOP3->szUIDL){
					GlobalFree(tpPOP3->szUIDL);
					tpPOP3->szUIDL = NULL;
				}
				tpPOP3->szUIDL = CalcMessageDigest(p);

				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_QUIT;
				ret = SendQUIT(tpItemInfo->Soc1);
			}
			else{
				tpPOP3->bMultiLine = FALSE;
				tpPOP3->state = POP3_QUIT;
				ret = SendQUIT(tpItemInfo->Soc1);
			}
			break;
		case POP3_QUIT:
			if(*tpPOP3->szBuf=='+'){
				int nUnReadMail,nPrevMail;
				char *szSize;
				
				szSize = Malloc(100);
				if(tpPOP3->nReadMail >= 0){
					nUnReadMail = tpPOP3->nMail - tpPOP3->nReadMail;
					wsprintf(szSize,
							 "���� %d ��/���� %d ��",
							 nUnReadMail,tpPOP3->nMail);
				}
				else{
					if(tpItemInfo->Size){
						sscanf(tpItemInfo->Size,"���� 0 ��/���� %d ��",&nPrevMail);
					}
					else{
						nPrevMail = 0;
					}
					wsprintf(szSize,"���� %d ��/���� %d ��",tpPOP3->nMail,tpPOP3->nMail);
				}
				if(tpItemInfo->Size){
					GlobalFree(tpItemInfo->Size);
					tpItemInfo->Size = NULL;
				}
				tpItemInfo->Size = szSize;

				if(tpPOP3->nReadMail >= 0){
					if(tpItemInfo->DLLData2){
						if(lstrcmp(tpItemInfo->DLLData2,tpPOP3->szUIDL)==0){
							Status = ST_DEFAULT;
						}
						else{
							if(tpPOP3->nMail > 0){
								// �Ō�̃��[����UIDL���ȑO�A�N�Z�X�����Ƃ��ƕς����
								// ���ă��[��������΍X�V
								Status = ST_UP;
								strcat(tpItemInfo->Size,"*");
							}
							else{
								Status = ST_DEFAULT;
							}
						}
						GlobalFree(tpItemInfo->DLLData2);
					}
					else{
						Status = ST_DEFAULT;
					}
					tpItemInfo->DLLData2 = DupStr(tpPOP3->szUIDL);
				}
				else{
					if(tpItemInfo->DLLData2){
						GlobalFree(tpItemInfo->DLLData2);
						tpItemInfo->DLLData2 = NULL;
					}
					if(tpPOP3->nMail > 0 && tpPOP3->nMail != nPrevMail){
						Status = ST_UP;
						strcat(tpItemInfo->Size,"*");
					}
					else{
						Status = ST_DEFAULT;
					}
				}
				if(tpItemInfo->Date){
					GlobalFree(tpItemInfo->Date);
					tpItemInfo->Date = NULL;
				}
				tpItemInfo->Date = GetCurrentTimeString();
			}
			else{
				bRetCode = FALSE;
				SetCustomErrorMessage(tpItemInfo,IDS_FAIL_QUIT);
			}
			if(bRetCode){
				SetStatusBar(hWnd,"�`�F�b�N�I��(%s)",tpPOP3->szServer);
				SendMessage(hWnd,WM_CHECKEND,Status,(LPARAM)tpItemInfo);
				return CHECK_END;
			}
			break;
	}
	tpPOP3->nDataSize = 0;
	if(ret == SOCKET_ERROR){
		return CHECK_ERROR;
	}
	if(bRetCode){
		return CHECK_SUCCEED;
	}
	else{
		SendMessage(hWnd,WM_CHECKEND,ST_ERROR,(LPARAM)tpItemInfo);
		return CHECK_ERROR;
	}
}

char * CalcMessageDigest(char *buf)
{
	MD5_CTX context;
	unsigned char digest[16];
	int i;
	char *szDigest = Malloc(16 * 2 + 1);

	MD5Init(&context);
	MD5Update(&context,buf,lstrlen(buf));
	MD5Final(digest,&context);

	for(i=0;i<16;i++){
		wsprintf(szDigest + i * 2,"%02x",digest[i]);
	}
	return szDigest;
}



int SendUser(int soc,char *szUser)
{
	char buf[256];
	wsprintf(buf,"USER %s\r\n",(szUser) ? szUser : "");
	return send(soc,buf,lstrlen(buf),0);
}

int SendPass(int soc,char *szPass)
{
	char buf[256];
	wsprintf(buf,"PASS %s\r\n",(szPass) ? szPass : "");
	return send(soc,buf,lstrlen(buf),0);
}

int Send(int soc,char *buf)
{
	return send(soc,buf,lstrlen(buf),0);
}

int SendUIDL(int soc,int num)
{
	char buf[256];
	if(num < 0){
#ifndef NO_SUPPORT_UIDL
		wsprintf(buf,"UIDL\r\n");
#else
		wsprintf(buf,"_UIDL\r\n");
#endif
	}
	else{
#ifndef NO_SUPPORT_UIDL
		wsprintf(buf,"UIDL %d\r\n",num);
#else
		wsprintf(buf,"_UIDL %d\r\n",num);
#endif
	}
	return send(soc,buf,lstrlen(buf),0);
}

int SendAPOP(int soc,char *szUser,char *szPass,char *szTimeStamp)
{
	MD5_CTX context;
	unsigned char digest[16];
	unsigned int len = lstrlen(szTimeStamp)+lstrlen(szPass)+lstrlen(szUser)+16*2+5;
	char *buf = Malloc(len + 1);
	char szDigest[16 * 2 + 1];
	int i,ret;

	if(buf == NULL){
		return -1;
	}
	if(szTimeStamp && szPass){
		wsprintf(buf,"%s%s",szTimeStamp,szPass);
	}
	else{
		*buf = '\0';
	}

	MD5Init(&context);
	MD5Update(&context,buf,lstrlen(buf));
	MD5Final(digest,&context);

	for(i=0;i<16;i++){
		wsprintf(szDigest + i * 2,"%02x",digest[i]);
	}
	wsprintf(buf,"APOP %s %s\r\n",
		(szUser)? szUser : "",szDigest);

	ret = send(soc,buf,lstrlen(buf),0);
	GlobalFree(buf);
	return ret;
}

int SendQUIT(int soc)
{
	return Send(soc,"QUIT\r\n");
}

int SendSTAT(int soc)
{
	return Send(soc,"STAT\r\n");
}

int SendLAST(int soc)
{
#ifndef NO_SUPPORT_LAST
	return Send(soc,"LAST\r\n");
#else
	return Send(soc,"_LAST\r\n");
#endif
}

int SendTop(int soc,int num)
{
	char buf[256];
#ifndef NO_SUPPORT_TOP
	wsprintf(buf,"TOP %d 0\r\n",num);
#else
	wsprintf(buf,"_TOP %d 0\r\n",num);
#endif
	return send(soc,buf,lstrlen(buf),0);
}

int SelectClose(HWND hWnd,struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	int ret = CHECK_ERROR;

	if(tpPOP3 && tpPOP3->state == POP3_QUIT){
		ret = CHECK_END;
	}
	CloseSocket(hWnd,tpItemInfo);
	return ret;
}

/*
 *	POP�T�[�o�[����Ԃ���鈥�A������APOP�̎��
 *	TPPOP3�\���̂�szTimeStamp�Ɋi�[����
 */
void ParseGreeting(struct TPPOP3 * tpPOP3)
{
	int n	  = lstrlen(tpPOP3->szBuf) + 1;
	char *buf = Malloc(n);
	char *p,*q,*r;
	
	tpPOP3->szTimeStamp = NULL;
	for(p=tpPOP3->szBuf;*p && *p != '<';p++);
	if(*p){
		for(q=p;*q && *q != '>';q++);
		if(*q){
			q++;
			for(r=buf;*p && p<q;){
				*r++ = *p++;
			}
			*r = '\0';
			tpPOP3->szTimeStamp = buf;
			return;
		}
	}
	GlobalFree(buf);
}

/*
 * ���݂̎�����\����������擾����
 */
char *GetCurrentTimeString(void)
{
	SYSTEMTIME sys;
	char *p;

	GetLocalTime(&sys);

	p = Malloc(4 + 2 + 2 + 2 + 2 + 6);
	wsprintf(p,"%04d/%02d/%02d %02d:%02d",
			 sys.wYear,sys.wMonth,sys.wDay,
			 sys.wHour,sys.wMinute);
	return p;
}

