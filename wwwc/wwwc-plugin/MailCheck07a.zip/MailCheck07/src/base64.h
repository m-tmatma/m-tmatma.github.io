/*
 *  MailCheck (WWWC�̃v���O�C��)
 *
 *  base64.h
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#ifndef _BASE_64_H_
#define _BASE_64_H_

int DecodeBase64(BYTE *pInput,BYTE *pOutput,int nLength);
int EncodeBase64(BYTE *pInput,BYTE *pOutput,int nLength);

#endif //#ifndef _BASE_64_H_
