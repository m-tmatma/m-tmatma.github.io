/*
 *  MailCheck (WWWC�̃v���O�C��)
 *
 *  Option.h
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#ifndef _OPTION_H_
#define _OPTION_H_

int GetOptionString(char *buf,char *value,int index);
int GetOptionInt(char *buf,int index);

#endif //#ifndef _OPTION_H_

