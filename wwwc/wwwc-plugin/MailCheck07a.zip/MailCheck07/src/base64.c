/*
 *  MailCheck (WWWC�̃v���O�C��)
 *
 *  base64.c
 *
 *  Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <stdio.h>

typedef unsigned long       DWORD;
typedef unsigned char       BYTE;
char * SkipCRLF(char *buf);

DWORD Base64ToNumber(char ch)
{
    if('A' <= ch && ch <= 'Z'){
        return ch - 'A';
    }
    else if('a' <= ch && ch <= 'z'){
        return ch - 'a' + 26;
    }
    else if('0' <= ch && ch <= '9'){
        return ch - '0' + 52;
    }
    else if(ch == '+'){
        return 62;
    }
    else if(ch == '='){
        return 0;
    }
    return 63;
}

BYTE Base64ToChar(BYTE ch)
{
    if(0 <= ch && ch <= 25){
        return ch + 'A';
    }
    else if(26 <= ch && ch <= 51){
        return ch - 26 + 'a';
    }
    else if(52 <= ch && ch <= 61){
        return ch - 52 + '0';
    }
    else if(ch == 62){
        return '+';
    }
    return '/';

}

char * SkipCRLF(char *buf)
{
    if(*buf == '\r'){
        buf++;
        if(*buf == '\n'){
            buf++;
        }
    }
    else if(*buf == '\n'){
        buf++;
    }
    return buf;
}

int DecodeBase64(BYTE *pInput,BYTE *pOutput,int nLength)
{
    BYTE *p = pInput;
    BYTE *q = pOutput;
    DWORD dwTemp;
    int i,j,nDecodeSize,nNumOfEqual;

    nNumOfEqual = 0;
    nDecodeSize = 0;
    for(j=0;j<nLength;j += 4){
        dwTemp = 0;
        for(i=0;i<4;i++){
            p = SkipCRLF(p);
            if(*p == '='){
                nNumOfEqual++;
            }
            dwTemp |= Base64ToNumber(*p++);
            if(i != 3)
                dwTemp <<= 6;
        }
        *q++ = (BYTE)(dwTemp >> 16) & 0xff;
        *q++ = (BYTE)(dwTemp >>  8) & 0xff;
        *q++ = (BYTE)dwTemp & 0xff;
    }
    *q = 0;
    return (q - pOutput) - nNumOfEqual;
}

int EncodeBase64(BYTE *pInput,BYTE *pOutput,int nLength)
{
    BYTE *p = pInput;
    BYTE *q = pOutput;
    int i,j;
    DWORD dwTemp;

    for(j=0;j<nLength;j += 3){
        dwTemp = 0;
        for(i=0;i<3;i++){
            dwTemp <<= 8;
            dwTemp |= *p++;
        }
        *q++ = Base64ToChar( (BYTE)((dwTemp >> 18) & 0x3f) );
        *q++ = Base64ToChar( (BYTE)((dwTemp >> 12) & 0x3f) );
        *q++ = Base64ToChar( (BYTE)((dwTemp >>  6) & 0x3f) );
        *q++ = Base64ToChar( (BYTE)(dwTemp & 0x3f) );
    }
    for(i=0;i < j-nLength;i++){
        *q++ = '=';
    }
    *q = 0;
    return q - pOutput;
}

static int GetDigit(BYTE ch)
{
    if('0' <= ch && ch <= '9'){
        return ch - '0';
    }
    else if('A' <= ch && ch <= 'F'){
        return ch - 'A' + 10;
    }
    else if('a' <= ch && ch <= 'f'){
        return ch - 'a' + 10;
    }
    return -1;
}
