//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MailCheck.rc
//
#define IDS_NOERROR                     0
#define IDS_FAIL_ALLOC_MEMORY           1
#define IDS_NOT_SUPPORT_APOP            2
#define IDS_WRONG_USER                  3
#define IDS_WRONG_PASS                  4
#define IDS_FAIL_QUIT                   5
#define IDD_DIALOG_PROP_GENERAL         101
#define IDD_DIALOG_PROP_STATUS          102
#define IDI_ICON_POP3                   103
#define IDC_EDIT_TITLE                  1000
#define IDC_EDIT_USER                   1001
#define IDC_EDIT_PASSWORD               1002
#define IDC_EDIT_SERVER                 1003
#define IDC_CHECK_APOP                  1004
#define IDC_EDIT_COMMENT                1005
#define IDC_EDIT_PORT                   1006
#define IDC_EDIT_MAIL_PATH              1007
#define IDC_EDIT_CMDLINE                1008
#define IDC_BUTTON_BROWSE               1009
#define IDC_STATIC_ERRTEXT              1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
