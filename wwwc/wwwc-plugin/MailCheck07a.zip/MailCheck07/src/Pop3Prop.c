/*
 *	MailCheck (WWWC�̃v���O�C��)
 *
 *	Pop3Prop.c
 *
 *	Writen by Masaru Tsuchiyama <m.tsutsu@gmail.com>
 */
#include <windows.h>
#include <commctrl.h>
#include "wwwcdll.h"
#include "Option.h"
#include "misc.h"
#include "Pop3.h"
#include "base64.h"
#include "resource.h"

extern HINSTANCE g_hInst;

static BOOL CALLBACK POP3Property(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
static BOOL CALLBACK POP3PropStatus(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

static void InitItemProperty(HWND hDlg,struct TPITEM *tpItemInfo);
static void SaveItemProperty(HWND hDlg,struct TPITEM *tpItemInfo);
static void BrowseMailerPath(HWND hDlg,int ID);

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u�̃_�C�A���O�v���[�V�W��
 */
static BOOL CALLBACK POP3Property(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	PROPSHEETPAGE *pPropSheet;
	struct TPITEM *tpItemInfo;
	NMHDR *nmhdr;

	switch (uMsg){
		case WM_INITDIALOG:
			pPropSheet = (PROPSHEETPAGE *)lParam;
			if(!pPropSheet||IsBadReadPtr(pPropSheet,sizeof(PROPSHEETPAGE))){
				return FALSE;
			}
			tpItemInfo = (struct TPITEM *)pPropSheet->lParam;
			InitItemProperty(hDlg,tpItemInfo);
			SetWindowLong(hDlg,DWL_USER,(long)tpItemInfo);
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch(nmhdr->code){
				case PSN_APPLY:
					tpItemInfo = (struct TPITEM *)GetWindowLong(hDlg,DWL_USER);
					if(tpItemInfo){
						SaveItemProperty(hDlg,tpItemInfo);
					}
					break;
				case PSN_QUERYCANCEL:
				case PSN_RESET:
				default:
					return FALSE;
			}
			SetWindowLong(hDlg,DWL_MSGRESULT,PSNRET_NOERROR);
			return TRUE;
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam)){
				case IDC_BUTTON_BROWSE:
					BrowseMailerPath(hDlg,IDC_EDIT_MAIL_PATH);
					break;
			}
			break;
		default:
			return FALSE;
	}
	return TRUE;

}

/*
 *	���[���[�̃p�X��ݒ肷��֐�
 */
void BrowseMailerPath(HWND hDlg,int ID)
{
	OPENFILENAME ofn;
	char szFileName[MAX_PATH];

	szFileName[0] = '\0';
	memset(&ofn,0,sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner	= hDlg;
	ofn.lpstrFilter = "���s�t�@�C��(*.exe)\0*.exe\0"
					  "���ׂẴt�@�C��(*.*)\0*.*\0\0";
	ofn.lpstrFile	= szFileName;
	ofn.nMaxFile	= MAX_PATH;
	ofn.Flags		= OFN_FILEMUSTEXIST;
	ofn.lpstrDefExt = "exe";
	if(GetOpenFileName(&ofn)){
		SetDlgItemText(hDlg,ID,szFileName);
	}
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̏�ԃ^�u�̃_�C�A���O�v���[�V�W��
 */
static BOOL CALLBACK POP3PropStatus(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	PROPSHEETPAGE *pPropSheet;
	struct TPITEM *tpItemInfo;
	NMHDR *nmhdr;

	switch (uMsg){
		case WM_INITDIALOG:
			pPropSheet = (PROPSHEETPAGE *)lParam;
			if(!pPropSheet||IsBadReadPtr(pPropSheet,sizeof(PROPSHEETPAGE))){
				return FALSE;
			}
			tpItemInfo = (struct TPITEM *)pPropSheet->lParam;
			SetWindowLong(hDlg,DWL_USER,(long)tpItemInfo);
			if(tpItemInfo->ErrStatus && *tpItemInfo->ErrStatus){
				SetDlgItemText(hDlg,IDC_STATIC_ERRTEXT,tpItemInfo->ErrStatus);
			}
			else{
				SetDlgItemText(hDlg,IDC_STATIC_ERRTEXT,"�G���[�Ȃ�");
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch(nmhdr->code){
				case PSN_APPLY:
					break;
				case PSN_QUERYCANCEL:
				case PSN_RESET:
				default:
					return FALSE;
			}
			SetWindowLong(hDlg,DWL_MSGRESULT,PSNRET_NOERROR);
			return TRUE;
		default:
			return FALSE;
	}
	return TRUE;
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O��\������R�[���o�b�N�֐�
 */
__declspec(dllexport) int CALLBACK POP3_Property(HWND hWnd, struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = NULL;
	PROPSHEETPAGE psp;
	PROPSHEETHEADER psh;
	HPROPSHEETPAGE hpsp[2];
	int ret,count;
	char *szTitle;

	if(tpItemInfo->Param1 == 0){
		tpPOP3 = Malloc(sizeof(struct TPPOP3));
		if(tpPOP3 == NULL){
			return -1;
		}
		tpItemInfo->Param1 = (long)tpPOP3;
		ParseParameter(tpItemInfo,tpPOP3);
	}

	tpPOP3->Version = GetWWWCVersion(hWnd);

	psp.dwSize	  = sizeof(PROPSHEETPAGE);
	psp.dwFlags   = PSP_DEFAULT;
	psp.hInstance = g_hInst;

	count = 0;
	psp.pszTemplate = MAKEINTRESOURCE(IDD_DIALOG_PROP_GENERAL);
	psp.pfnDlgProc	= POP3Property;
	psp.lParam		= (LPARAM)tpItemInfo;
	hpsp[count++] = CreatePropertySheetPage(&psp);

	psp.pszTemplate = MAKEINTRESOURCE(IDD_DIALOG_PROP_STATUS);
	psp.pfnDlgProc	= POP3PropStatus;
	psp.lParam		= (LPARAM)tpItemInfo;
	hpsp[count++] = CreatePropertySheetPage(&psp);

	if(tpItemInfo->Title){
		szTitle = Malloc(32 + lstrlen(tpItemInfo->Title) + 1);
		if(szTitle){
			wsprintf(szTitle, "%s�̃v���p�e�B", tpItemInfo->Title);
		}
	}
	else{
		szTitle = Malloc(32 + 1);
		if(szTitle){
			lstrcpy(szTitle,"�V�����A�J�E���g�̃v���p�e�B");
		}
	}
	if(szTitle == NULL){
		return -1;
	}

	memset(&psh,0,sizeof(PROPSHEETHEADER));
	psh.dwSize	   = sizeof(PROPSHEETHEADER);
	psh.dwFlags    = PSH_NOAPPLYNOW;
	psh.hInstance  = g_hInst;
	psh.hwndParent = hWnd;
	psh.pszCaption = szTitle;
	psh.nPages = count;
	psh.phpage = hpsp;
	psh.nStartPage = 0;

	ret = -1;
	if(PropertySheet(&psh) > 0){
		ret = 0;
		SaveOption(tpItemInfo,tpPOP3);
	}
	if(szTitle){
		GlobalFree(szTitle);
		szTitle = NULL;
	}
	GlobalFree(tpPOP3);
	tpItemInfo->Param1 = 0;
	return ret;
}

/*
 * �R�����g�̓��͗��̃E�B���h�E�X�^�C����ݒ肷��
 */
void SetupComment(HWND hDlg, int nID, unsigned long Version)
{
	LONG Style;
	HWND hEditComment;

	hEditComment = GetDlgItem(hDlg, nID);
	Style = GetWindowLong( hEditComment, GWL_STYLE);

	switch(CmpVersion(Version, 1, 0, 3, 0)){
	case  0:
	case  1:
		Style |= (ES_MULTILINE | ES_WANTRETURN);
		break;	
	case -1:
		Style &= ~(ES_WANTRETURN|ES_MULTILINE);
		break;
	}
	SetWindowLong( hEditComment, GWL_STYLE, Style);
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u������������֐�
 */
void InitItemProperty(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	char *szPath,*szCmdLine;

	if(tpPOP3 == NULL){
		return;
	}
	if(tpItemInfo->Title){
		SetDlgItemText(hDlg,IDC_EDIT_TITLE,tpItemInfo->Title);
	}
	else{
		SetDlgItemText(hDlg,IDC_EDIT_TITLE,"�V�����A�J�E���g");
	}
	SetDlgItemText(hDlg,IDC_EDIT_SERVER,tpPOP3->szServer);
	SetDlgItemInt(hDlg,IDC_EDIT_PORT,tpPOP3->nPort,FALSE);

	// �A�J�E���g�ƃp�X���[�h��ݒ肷��
	SetDlgItemText(hDlg,IDC_EDIT_USER,	  tpPOP3->szUser);
	SetDlgItemText(hDlg,IDC_EDIT_PASSWORD,tpPOP3->szPass);

	CheckDlgButton(hDlg,IDC_CHECK_APOP	 ,tpPOP3->bUseAPOP);

	if(tpItemInfo->Comment){
		SetDlgItemText(hDlg,IDC_EDIT_COMMENT,tpItemInfo->Comment);
	}
	SetupComment(hDlg, IDC_EDIT_COMMENT, tpPOP3->Version);

	// ���[���[��ݒ肷��
	szPath = DupStr(tpItemInfo->DLLData1);
	if(szPath){
		RemoveArgs(szPath);
		szCmdLine = GetArgs(tpItemInfo->DLLData1);

		SetDlgItemText(hDlg,IDC_EDIT_MAIL_PATH,szPath);
		SetDlgItemText(hDlg,IDC_EDIT_CMDLINE  ,szCmdLine);

		GlobalFree(szPath);
	}
}

/*
 *	�A�C�e���̃v���p�e�B�_�C�A���O�̑S�ʃ^�u�̐ݒ��ۑ�����֐�
 */
void SaveItemProperty(HWND hDlg,struct TPITEM *tpItemInfo)
{
	struct TPPOP3 *tpPOP3 = (struct TPPOP3 *)tpItemInfo->Param1;
	char *szMailer,*szCmdLine;
	char *p,*buf;

	// �^�C�g���̐ݒ�
	if(tpItemInfo->Title){
		GlobalFree(tpItemInfo->Title);
		tpItemInfo->Title = NULL;
	}
	tpItemInfo->Title = GetDlgEditText(hDlg,IDC_EDIT_TITLE);

	// �`�F�b�N����URL�̐ݒ�
	if(tpItemInfo->CheckURL){
		GlobalFree(tpItemInfo->CheckURL);
		tpItemInfo->CheckURL = NULL;
	}
	buf = GetDlgEditText(hDlg,IDC_EDIT_SERVER);
	if(buf){
		tpItemInfo->CheckURL = Malloc(lstrlen(buf) + sizeof("pop://") + 1);
		wsprintf(tpItemInfo->CheckURL,"pop://%s",buf);
		GlobalFree(buf);
		buf = NULL;
	}
	else{
		tpItemInfo->CheckURL = DupStr("pop://");
	}

	// �R�����g�̐ݒ�
	if(tpItemInfo->Comment){
		GlobalFree(tpItemInfo->Comment);
		tpItemInfo->Comment = NULL;
	}

	tpItemInfo->Comment = GetDlgEditText(hDlg,IDC_EDIT_COMMENT);
	if(CmpVersion(tpPOP3->Version, 1, 0, 3, 0) < 0){
		/* ���s����̃R�����g���󂯕t����̂� ver 1.0.3�ȍ~*/
		DeleteReturn(tpItemInfo->Comment);
	}

	// �A�J�E���g�ƃp�X���[�h���擾
	GetDlgItemText(hDlg,IDC_EDIT_USER,tpPOP3->szUser,sizeof(tpPOP3->szUser));
	GetDlgItemText(hDlg,IDC_EDIT_PASSWORD,tpPOP3->szPass,sizeof(tpPOP3->szPass));

	tpPOP3->nPort	 = GetDlgItemInt(hDlg,IDC_EDIT_PORT,NULL,FALSE);
	tpPOP3->bUseAPOP = IsDlgButtonChecked(hDlg,IDC_CHECK_APOP);

	// ���[���[�̃p�X�ƃp�����[�^��ۑ�
	if(tpItemInfo->DLLData1){
		GlobalFree(tpItemInfo->DLLData1);
		tpItemInfo->DLLData1 = NULL;
	}
	szMailer = GetDlgEditText(hDlg,IDC_EDIT_MAIL_PATH);
	szCmdLine= GetDlgEditText(hDlg,IDC_EDIT_CMDLINE);
	if(szMailer){
		int nPath = 0,nParam = 0;
		nPath  = lstrlen(szMailer);
		if(szCmdLine){
			nParam = lstrlen(szCmdLine);
		}
		tpItemInfo->DLLData1 = Malloc(nPath + nParam + 4);
		if(*szMailer != '"'){
			if(szCmdLine){
				wsprintf(tpItemInfo->DLLData1,"\"%s\" %s",szMailer,szCmdLine);
			}
			else{
				wsprintf(tpItemInfo->DLLData1,"\"%s\"",szMailer);
			}
		}
		else{
			if(szCmdLine){
				wsprintf(tpItemInfo->DLLData1,"%s %s",szMailer,szCmdLine);
			}
			else{
				wsprintf(tpItemInfo->DLLData1,"%s",szMailer);
			}
		}
	}
	if(szMailer)	GlobalFree(szMailer);
	if(szCmdLine)	GlobalFree(szCmdLine);

}

/*
 *	TPITEM�\���̂̃I�v�V�������������͂���֐�
 */
BOOL ParseParameter(struct TPITEM *tpItemInfo, struct TPPOP3 *tpPOP3)
{
	if(tpItemInfo->CheckURL){
		char *p;
		p = GetServNameFromCheckURL(tpItemInfo->CheckURL);
		lstrcpy(tpPOP3->szServer,p);
		p = tpPOP3->szServer;

		// '/'����菜��
		while(*p && *p != '/'){
			p++;
		}
		if(*p){
			*p = '\0';
		}
	}
	else{
		lstrcpy(tpPOP3->szServer,"");
	}

	if(tpItemInfo->Option1){
		char szTmp[BUFSIZE];
		GetOptionString(tpItemInfo->Option1,tpPOP3->szUser,0);
		GetOptionString(tpItemInfo->Option1,szTmp,1);
		DecodeBase64(szTmp,tpPOP3->szPass,lstrlen(szTmp));
		tpPOP3->bUseAPOP = GetOptionInt(tpItemInfo->Option1,2);
		tpPOP3->nPort	 = GetOptionInt(tpItemInfo->Option1,3);
	}
	else{
		struct servent *pSrv = getservbyname("pop3","tcp");
		if(pSrv){
			tpPOP3->nPort = ntohs(pSrv->s_port);
		}
		else{
			tpPOP3->nPort = ntohs(110);
		}
		tpPOP3->bUseAPOP = 0;
		*tpPOP3->szUser = '\0';
		*tpPOP3->szPass = '\0';
	}
	return TRUE;
}

/*
 *	�ݒ��TPITEM�\���̂̃I�v�V����������ɕۑ�����֐�
 */
void SaveOption(struct TPITEM *tpItemInfo, struct TPPOP3 *tpPOP3)
{
	int nBufSize;

	nBufSize = 50;
	if(*tpPOP3->szUser){
		nBufSize += lstrlen(tpPOP3->szUser) + 1;
	}
	if(*tpPOP3->szPass){
		nBufSize += 2 * lstrlen(tpPOP3->szPass) + 1;
	}
	if(tpItemInfo->Option1){
		GlobalFree(tpItemInfo->Option1);
		tpItemInfo->Option1 = NULL;
	}
	tpItemInfo->Option1 = Malloc(nBufSize);
	if(tpItemInfo->Option1){
		char * szEncode = NULL;
		if(*tpPOP3->szPass){
			szEncode = Malloc(lstrlen(tpPOP3->szPass) * 2 + 1);
			if(szEncode){
				EncodeBase64(tpPOP3->szPass,szEncode,lstrlen(tpPOP3->szPass));
			}
		}

		// tpItemInfo->Option1�ɃI�v�V������ۑ�
		wsprintf(tpItemInfo->Option1,
			 "%s;%s;%d;%d",
			 tpPOP3->szUser,(szEncode) ? szEncode : "",
			 tpPOP3->bUseAPOP,
			 tpPOP3->nPort );
		if(szEncode){
			GlobalFree(szEncode);
		}
	}

}
